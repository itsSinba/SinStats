-------------------------
-- SinStats Configuration
-------------------------
local AddName, AddonTable = ...
local addVer = "2.9"
local byPass

AddonTable.Groups = { "Melee", "Ranged", "Spell", "Resistance", "Misc" }

function AddonTable:UpdateStatus()
	SinStatsFrame:SetShown(not SinStatsDB.SinHideVar)
	local locked = SinStatsDB.SinLockVar
	SinStatsFrame:SetBackdropColor(1, 1, 1, locked and 0 or 1)
	SinStatsFrame:EnableMouse(not locked)
	SinStatsFrame.DragText:SetShown(not locked)
end

local SinStatsConfig = CreateFrame("frame","SinStatsConfigFrame", UIParent, 'ShadowOverlayTemplate')
SinStatsConfig:SetMovable(true)
SinStatsConfig:SetClampedToScreen(true)
SinStatsConfig:SetUserPlaced(true)
SinStatsConfig:Hide()

function AddonTable:ToggleConfig()
	local Configs = {
		AP = { label=" Attack Power", tooltip=false, },
		APud = { label=" Attack Power [Undead]", tooltip="Displays the total attack power against an Undead NPC", },		
		RAP = { label=" Attack Power", tooltip=false, },
		RAPud = { label=" Attack Power [Undead]", tooltip="Displays the total attack power against an Undead NPC", },			
		DMG = { label=" Damage", tooltip=false, },
		RDMG = { label=" Damage", tooltip=false, },
		Fire = { label=" Fire Power", tooltip="Includes Fire damage from gear, consumables, enchants and talents", },		
		Frost = { label=" Frost Power", tooltip="Includes Frost damage from gear, consumables, enchants and talents", },		
		Arcane = { label=" Arcane Power", tooltip="Includes Arcane damage from gear, consumables, enchants and talents", },
		Shadow = { label=" Shadow Power", tooltip="Includes Shadow damage from gear, consumables, enchants and talents", },			
		Nature = { label=" Nature Power", tooltip="Includes Nature damage from gear, consumables, enchants and talents", },
		Healing = { label=" Healing Power", tooltip="Includes +healing from gear, consumables, enchants and talents", },
		Holy = { label=" Holy Power", tooltip="Includes Holy damage from gear, consumables, enchants and talents", },		
		spellUD = { label=" Undead Power", tooltip="Displays the spell damage against an Undead NPC, based on your highest spell damage", },				
		Crit = { label=" Critical Strike", tooltip=false, },    
		CritCap = { label=" Critical Cap", tooltip="Displays the Critical Strike Cap against a Raid Boss based on the weapons used and other character stats", },    		
		RangedCrit = { label=" Critical Strike", tooltip=false, },
		SpellCrit = { label=" Critical Strike", tooltip="Talent spell-specific Crit is colored\n(Grey = Priest's Holy Specialization)", },
		Hit = { label=" Hit", tooltip=false, },
		RangedHit = { label=" Hit", tooltip=false, },
		HasteMelee = { label=" Haste", tooltip="Haste bonus percentage from abilities procs, enchants,\ntalents, trinkets, consumables, buffs and world buffs", },
		weaponSpeed = { label=" Attack Speed", tooltip="Weapon speed for Main Hand and Off Hand", },
		MeleeMiss = { label=" Miss Chance", tooltip="Melee miss chance against NPC of the same level", },
		MeleeBoss = { label=" Miss vs Boss", tooltip="Melee miss chance against NPC of +3 levels", },
		HasteRanged = {  label=" Haste", tooltip="Haste bonus percentage from abilities procs, enchants\ntalents, trinkets, consumables, buffs and world buffs", },
		rangedSpeed = {  label=" Attack Speed", tooltip="Weapon speed of the equipped range weapon", },		
		RangedMiss = { label=" Miss Chance", tooltip="Ranged miss chance against NPC of the same level", },
		RangedBoss = { label=" Miss vs Boss", tooltip="Ranged miss chance against NPC of +3 levels", },
		SpellHit = { label=" Hit", tooltip="Talent spell-specific Hit is colored\n(Blue = Mage's Arcane Focus, Purple = Priest's Shadow Focus)", },
		HasteCaster = { label=" Haste", tooltip="Haste bonus percentage from abilities procs,\ntalents, trinkets, consumables, buffs and world buffs", },
		SpellMiss = { label=" Miss Chance", tooltip="Spell miss chance against NPC of the same level", },
		SpellBoss = { label=" Miss vs Boss", tooltip="Spell miss chance against NPC of +3 levels", },
		ManaRegen = { label=" Mana Regen", tooltip="Mana Regen per tick while not casting", },
		CastingRegen = { label=" Casting Regen", tooltip="Mana Regen per tick while casting", },
		MP5Cast = { label=" MP5", tooltip="MP5 value from gear, enchants, consumables and world buffs", },
		Armor = { label=" Armor", tooltip=false, },
		DMGReduc = { label=" Mitigation", tooltip="Percentage of damage reduction against NPC of the same level" , },
		Defense = { label=" Defense", tooltip=false, },
		Dodge = { label=" Dodge", tooltip=false, },
		Parry = { label=" Parry", tooltip=false, },
		Block = { label=" Block", tooltip=false, },
		FireResist = { label=" Fire", tooltip=false, },
		FrostResist = { label=" Frost", tooltip=false, },
		ShadowResist = { label=" Shadow", tooltip=false, },
		ArcaneResist = { label=" Arcane", tooltip=false, },		
		NatureResist = { label=" Nature", tooltip=false, },
		Speed = { label=" Movement Speed", tooltip=false, },
		Durability = { label=" Durability", tooltip=false, },
		Lag = { label=" Latency [ms]", tooltip=false, },
		FPS = { label=" Framerate [FPS]", tooltip=false, },
	}
	for i= 1, #AddonTable.DisplayOrder do
		if not 	Configs[AddonTable.DisplayOrder[i].hud] then
			print("|cffff0000SinStats: MISSING Config entry << ".. AddonTable.DisplayOrder[i].hud.." >>|r")
		end
	end
	-----------------------------------------------------
	-- Factory functions for creating check boxes
	-----------------------------------------------------
	local function OnEnter(self)
		local parent = self.tooltip and self or self:GetParent()
		GameTooltip:SetOwner(parent, "ANCHOR_LEFT")
		GameTooltip:SetText(parent.tooltip)
	end

	local function OnLeave()
		GameTooltip:Hide()
	end

	local function CreateCheckBox(parent, name, label, key, entry, tooltip)
		local f = CreateFrame("CheckButton", "$parent"..name, parent, "UICheckButtonTemplate")
		f:SetSize(20, 20)
		f.LabelButton = CreateFrame("Button", "$parentButton", f)
		f.LabelButton:SetHighlightTexture("Interface/QuestFrame/UI-QuestTitleHighlight")
		f.LabelButton:GetHighlightTexture():SetBlendMode("ADD")
		f.LabelButton:SetPoint("LEFT", f, "RIGHT", 5, 0)
		f.LabelButton:SetScript("OnClick", function(self)
			self:GetParent():Click()
		end)
		f.Label = f:CreateFontString("$parentLabel", "OVERLAY")
		f.Label:SetFontObject(GameFontNormal)
		f.Label:SetJustifyV("CENTER")
		f.Label:SetTextColor(1, 1, 1, 1)
		f.Label:SetPoint("LEFT", f.LabelButton)
		local w, h = f.Label:GetSize()
		f.LabelButton:SetSize(w+5, h)
		f.key = key
		f.entry = entry
		f:SetChecked(key[entry])
		f:SetScript("OnClick", function(self)
			self.key[self.entry] = self:GetChecked()
			if not self.ignoreUpdate then
				SinStatsFrame.Stats[self.entry]:SetShown(self:GetChecked())
			end
			SinStatsFrame:RedrawStats()
			PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
		end)
		f:SetScript("OnDisable", function(self)
			self.Label:SetAlpha(0.5)
		end)
		f:SetScript("OnEnable", function(self)
			self.Label:SetAlpha(1)
		end)
		function f:SetText(text)
			self.Label:SetText(text)
			self.LabelButton:SetSize(self.Label:GetSize())
		end
		f:SetText(label)
		if tooltip then
			f.tooltip = tooltip
			f:SetScript("OnEnter",  OnEnter)
			f:SetScript("OnLeave",  OnLeave)
			f.LabelButton:SetScript("OnEnter",  OnEnter)
			f.LabelButton:SetScript("OnLeave",  OnLeave)
		end
		return f
	end

	-----------------------------------------------------
	-- Factory functions for creating sheets and tabs
	-----------------------------------------------------
	local function TabOnClick(self) 
		PlaySound(SOUNDKIT.IG_CHARACTER_INFO_TAB)
		local ID = self:GetID()
		self:SetAlpha(1)
		self.widgets:Show()
		local parent = self:GetParent()
		for i=1, #parent.Tabs do
			if i ~= ID then
				parent.Tabs[i]:SetAlpha(0.5)
				parent.Tabs[i].widgets:Hide()
			end
		end
	end
     
	local function CreateTab(id, parent, text)
		local f = CreateFrame("Button", "$parentTab"..id, parent, "ConfigCategoryButtonTemplate")
		f:Hide()
		tinsert(parent.Tabs, f)
		f:SetID(id)
		f:SetText(text)
		local Text = _G[f:GetName().."NormalText"]
		Text:ClearAllPoints()
		Text:SetAllPoints()
		Text:SetJustifyH("CENTER")
		local width = parent:GetWidth() - 20
		f:SetSize(width / 6, Text:GetHeight() + 10)
		f:SetHighlightTexture("Interface\\PaperDollInfoFrame\\UI-Character-Tab-Highlight")
		if id == 1 then
			f:SetPoint("TOPLEFT",parent,"TOPLEFT", 0, 0)
		else
			f:SetPoint("LEFT",parent.Tabs[id-1],"RIGHT", 0, 0)
		end
		f.widgets = CreateFrame("Frame", nil, f)
		f.widgets:Hide()
		f.widgets:SetSize(parent:GetWidth(), parent:GetHeight() - f:GetHeight()) 
		f.widgets:SetPoint("TOPLEFT", parent.Tabs[1], "BOTTOMLEFT")
		f:SetScript("OnClick", TabOnClick)
		f:Show()
		return f
	end

	-----------------------------------------------------
	-- Factory functions for other stuff
	-----------------------------------------------------
	local function CreateSheetLabel(parent, text)
		local f = parent:CreateFontString("$parentLabel", "OVERLAY");
		f:SetFontObject("GameFontHighlight");
		f:SetText(text)
		return f
	end

	local function AddCheckBoxes(sheet, group, colwidth, rowoffset, coloffset)
		local Entries = {}
		for i=1, #AddonTable.DisplayOrder do
			if AddonTable.DisplayOrder[i].grp == group then
				tinsert(Entries, i)
			end
		end
		local row = rowoffset
		local col = coloffset
		local colcount = 1
		local rowmax = math.floor(#Entries/3)
		local over = mod(#Entries, 3)
		local rowcount = 0
		for i=1, #Entries do 
			local Settings = AddonTable.DisplayOrder[Entries[i]]
			local ConfigSettings = Configs[Settings.hud]
			local f = CreateCheckBox(sheet, Settings.hud, Settings.icon..ConfigSettings.label, SinStatsDB.Stats, Settings.hud, ConfigSettings.tooltip)
			f:SetPoint("TOPLEFT", sheet, col, row)
			rowcount = rowcount + 1
			if ((over > 0 and colcount <= over) and rowcount == rowmax+1) or (colcount > over and rowcount == rowmax) then
				colcount = colcount + 1
				col = col + colwidth
				row = rowoffset
				rowcount = 0
			else
				row = row - 25
			end
		end
	end

	-----------------------------------------------------
	-- Hide/Show or Create the config. frame
	-----------------------------------------------------
	if SinStatsConfig.Init then
		SinStatsConfig:SetShown(not SinStatsConfig:IsShown())
		return
	end
	local f = SinStatsConfig
	f.Init = true
	f:Show()
	f:SetBackdrop({
		bgFile="Interface/DialogFrame/UI-DialogBox-Background-Dark",
		--edgeFile="Interface/DialogFrame/UI-DialogBox-Background-Dark",
		tile=1, tileSize=0, edgeSize=5,
	 })
	f:SetBackdropColor(1,1,1,1)
	f:SetWidth(600)
	f:SetHeight(305)
	f:SetPoint("CENTER",UIParent)
	f:EnableMouse(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", function(self) self:StartMoving() end)
	f:SetScript("OnDragStart", function(self) self:StartMoving() end)
	f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
	f:SetFrameStrata("FULLSCREEN_DIALOG")
	tinsert(UISpecialFrames, "SinStatsConfigFrame")
	f.Close = CreateFrame('Button', '$parentClose', f, "UIPanelCloseButton")
	f.Close:SetPoint('TOPRIGHT', 0,0)
	f.Close:SetSize(25, 25)
	f.Close:SetScript('OnClick', function(self)
		self:GetParent():Hide()
	end)
	
	f.Title = f:CreateFontString(nil, "OVERLAY");
	f.Title:SetFontObject("GameFontHighlight");
	f.Title:SetPoint("TOP", SinStatsConfig, "TOP", 0, -3);
	f.Title:SetText("|cff0489d1SinStats : Classic|r");		

	local TabSettings = SinStatsDB.Stats
 	f.Tabs = {}
	local tab = CreateTab(1, f, "HUD") 
	tab:ClearAllPoints() 
	tab:SetPoint("TOPLEFT", 10, -40)
	local sheet = tab.widgets
	local colWidth = (sheet:GetWidth()-10)/3
	local colOffset = 35
	local rowOffset = -50
	
	sheet.Reset = CreateFrame('Button', '$parentReset', sheet, "UIPanelButtonTemplate")
	sheet.Reset:SetSize(115, 25)
	sheet.Reset:SetText("Reset Position")
	sheet.Reset:SetPoint("BOTTOMLEFT", -1, 43)
	sheet.Reset:SetScript('OnClick', function(self)
		StaticPopup_Show("SINSTATS_HUD_RESET")
	end)	
	
	sheet.SigVer = CreateSheetLabel(sheet, "|cff0489d1" .. addVer .. "|r");	
	sheet.SigVer.ignoreUpdate = true
	sheet.SigVer:SetFontObject("GameFontHighlightSmall");	
	sheet.SigVer:SetPoint('BOTTOMRIGHT', -15, 43);		
	--sheet.SigVer:SetText("|cff0489d1version " .. addVer .. " | Sinba-Pagle|r");	

	sheet.Label = CreateSheetLabel(sheet, "|cfff39c33HUD Settings|r")
	sheet.Label:SetPoint("TOP", sheet, "TOP", 0, -20);	
	
	sheet.Enable = CreateCheckBox(sheet, "Enable", "", SinStatsDB, "SinHideVar", "Disable the Stats Frame")
	sheet.Enable.ignoreUpdate = true
	sheet.Enable:SetPoint('TOPLEFT', 120, -50)
	sheet.Enable:HookScript('OnClick', function(self)
	        local Setting = self.key[self.entry]
		self:SetText(Setting and "HUD [|cffd4080cDisabled|r]" or "HUD [|cff00f26dEnabled|r]")
		AddonTable:UpdateStatus()
		if Setting and not self:GetParent().Locked:GetChecked() then
			--self:GetParent().Locked:Click()
		end
		self:GetParent().Locked:SetEnabled(not Setting)
	end)

	sheet.Locked = CreateCheckBox(sheet, "Locked", "", SinStatsDB, "SinLockVar", "Locks/Unlocks the Stats frame to move it")
	sheet.Locked.ignoreUpdate = true
 	sheet.Locked:SetPoint('TOP', 20, -50)
 	sheet.Locked:HookScript('OnClick', function(self)
		local Locked = self.key[self.entry]
         	self:SetText(Locked and "HUD [|cffd4080cLocked|r]" or "HUD [|cff00f26dUnlocked|r]")
         	AddonTable:UpdateStatus()
	end)
	sheet.Locked:GetScript('OnClick')(sheet.Locked)
	sheet.Enable:GetScript('OnClick')(sheet.Enable)
	
	sheet.mmToggle = CreateCheckBox(sheet, "mmToggle", "", SinStatsDB.minimap, "hide", "Toggle the minimap button")
	sheet.mmToggle:SetPoint("TOP", sheet.Enable, "BOTTOM", 0, -5);
	sheet.mmToggle.ignoreUpdate = true		
	if SinStatsDB.minimap.hide then
		byPass = true
	else	
		byPass = false
	end
	sheet.mmToggle:SetScript("OnClick", function(self)
    self.key[self.entry] = not self:GetChecked()
    local mmHide = self.key[self.entry]
    self:SetText(mmHide and "Minimap Icon [|cffC41E3ADisabled|r]" or "Minimap Icon [|cff00f26dEnabled|r]")
	
    if SinStatsDB.minimap.hide and byPass then
		AddonTable.sshMiniButton:Hide("SinStats") 
	elseif SinStatsDB.minimap.hide and not byPass then
		LibDBIcon10_SinStats:Hide()
    elseif not SinStatsDB.minimap.hide and byPass then
		AddonTable.sshMiniButton:Show("SinStats") 
	elseif not SinStatsDB.minimap.hide and not byPass then		
		LibDBIcon10_SinStats:Show()
    end
	end)          
	sheet.mmToggle:SetChecked(not SinStatsDB.minimap.hide)
	sheet.mmToggle:GetScript('OnClick')(sheet.mmToggle)		
	
	sheet.Order = CreateCheckBox(sheet, "Order", "", SinStatsDB, "GroupOrder", "Order the stats using the default order or by group (Melee, Ranged, Spell, etc.)")
	sheet.Order:SetPoint("TOP", sheet.mmToggle, "BOTTOM", 0, -5)
	sheet.Order.ignoreUpdate = true	
	sheet.Order:HookScript("OnClick", function(self)	
	self:SetText(self.key[self.entry] and "Stats Order [|cff0489d1Group|r]" or "Stats Order [|cff00f26dDefault|r]")	
	end)
	sheet.Order:GetScript("OnClick")(sheet.Order)		

	sheet.Icons = CreateCheckBox(sheet, "Icons", "", SinStatsDB, "IconVar", "Toggles the icons on the HUD")
	sheet.Icons.ignoreUpdate = true
 	sheet.Icons:SetPoint('TOP', sheet.Locked, 'BOTTOM', 0, -5)
	sheet.Icons:HookScript("OnClick", function(self)
		self:SetText(self.key[self.entry] and "Stats Icons [|cff00f26dEnabled|r]" or "Stats Icons [|cffd4080cDisabled|r]")
		SinStatsFrame.AddIcons = self.key[self.entry]
		AddonTable:RunAllEvents()
		SinStatsFrame:GetScript("OnUpdate")(SinStatsFrame, 5)
	end)		
	sheet.Icons:GetScript('OnClick')(sheet.Icons)
	
	sheet.Outline = CreateCheckBox(sheet, "Outline", "", SinStatsDB, "OutlineVar", "Toggle between Normal or Thick outline text")
	sheet.Outline:SetPoint("TOP", sheet.Icons, "BOTTOM", 0, -5)
	sheet.Outline.ignoreUpdate = true	
	sheet.Outline:HookScript("OnClick", function(self)	
		self:SetText(self.key[self.entry] and "Text Ouline [|cff0489d1Thick|r]" or "Text Outline [|cff00f26dNormal|r]")	
		SinStatsFrame:ResizeStats()
	end)
	sheet.Outline:GetScript("OnClick")(sheet.Outline)		
	
	sheet.Direction = CreateCheckBox(sheet, "Direction", "", SinStatsDB, "SinDirection", "Change the stats text's alignment and rows")
    sheet.Direction.ignoreUpdate = true
    sheet.Direction:SetPoint('TOP', sheet.Outline, 'BOTTOM', 0, -5)
    sheet.Direction:HookScript('OnClick', function(self)
        local Setting = self.key[self.entry]
        self:SetText(Setting and "HUD Text Alignment [|cff0489d1Horizontal|r]" or "HUD Text Alignment [|cff00f26dVertical|r]")
        SinStatsFrame:RedrawStats()
        self:GetParent().Rows:SetShown(self:GetChecked())
    end)
    sheet.Direction:SetText(SinStatsDB.SinDirection and "HUD Text Alignment [|cff0489d1Horizontal|r]" or "HUD Text Alignment [|cff00f26dVertical|r]")
	
	sheet.Rows = CreateFrame("Slider", "SinStatsSlider", sheet, 'OptionsSliderTemplate')
    sheet.Rows:SetShown(SinStatsDB.SinDirection)
    sheet.Rows:SetPoint("TOPLEFT", sheet.Direction, "BOTTOMLEFT", 35, -23)
    sheet.Rows.Low:SetText('1'); 
    sheet.Rows.High:SetText('5');   
    sheet.Rows.Text:SetText('Stats Rows');
    sheet.Rows:SetMinMaxValues(1, 5)
    sheet.Rows:SetValueStep(1)
    sheet.Rows.key = SinStatsDB
    sheet.Rows.entry = "StatRows"
    sheet.Rows:SetValue(SinStatsDB.StatRows or 1)
    sheet.Rows.Label = sheet.Rows:CreateFontString(nil, "OVERLAY");
    sheet.Rows.Label:SetFontObject("GameFontHighlightSmall");
    sheet.Rows.Label:SetPoint("TOP", sheet.Rows, "BOTTOM", 0, -5);     
    sheet.Rows:SetScript("OnValueChanged", function (self)
        local value = math.floor(self:GetValue())
        self.key[self.entry] = value
        SinStatsFrame:RedrawStats()
        self.Label:SetText("Current: " .. self.key[self.entry])
    end)
    sheet.Rows:GetScript("OnValueChanged")(sheet.Rows)	

	sheet.Abbreviate = CreateCheckBox(sheet, "Abbreviate", "", SinStatsDB, "SinAbrev", "Toggle between Normal or Abbreviated Stats Text")
	sheet.Abbreviate:SetPoint("TOP", sheet.Order, "BOTTOM", 0, -5)
	sheet.Abbreviate.ignoreUpdate = true	
	sheet.Abbreviate:HookScript("OnClick", function(self)	
	self:SetText(self.key[self.entry] and "HUD Text Style [|cff0489d1Short|r]" or "HUD Text Style [|cff00f26dNormal|r]")	
	AddonTable:RunAllEvents()
	end)
	sheet.Abbreviate:GetScript("OnClick")(sheet.Abbreviate)		
	
	sheet.Size = CreateFrame("Slider", "SinStatsSlider", sheet, 'OptionsSliderTemplate')
	sheet.Size:SetPoint('TOP', sheet.Abbreviate, 'BOTTOM', 85, -23)
	sheet.Size.Low:SetText('8'); 
	sheet.Size.High:SetText('40');   
	sheet.Size.Text:SetText('HUD Text Size');
	sheet.Size:SetMinMaxValues(8, 40)
	sheet.Size:SetValueStep(1)
	sheet.Size.key = SinStatsDB
	sheet.Size.entry = "StatFontSize"
	sheet.Size:SetValue(SinStatsDB.StatFontSize)
	sheet.Size.Label = sheet.Size:CreateFontString(nil, "OVERLAY");
	sheet.Size.Label:SetFontObject("GameFontHighlightSmall");
	sheet.Size.Label:SetPoint("TOP", sheet.Size, "BOTTOM", 0, -5);		
	sheet.Size:SetScript("OnValueChanged", function (self)
		local value = math.floor(self:GetValue())
		self.key[self.entry] = value
		SinStatsFrame:ResizeStats()
		self.Label:SetText("Current: " .. self.key[self.entry])
	end)
	sheet.Size:GetScript("OnValueChanged")(sheet.Size)

	for grp=1, #AddonTable.Groups do
		tab = CreateTab(grp+1, f, AddonTable.Groups[grp])
		sheet = tab.widgets 
		sheet.Label = CreateSheetLabel(sheet, "|cfff39c33"..AddonTable.Groups[grp].." Settings|r")
		sheet.Label:SetPoint("TOP", sheet, "TOP", 0, -20);
		AddCheckBoxes(sheet, grp, colWidth, rowOffset, colOffset)
	end
	
	TabOnClick(f.Tabs[1])
end

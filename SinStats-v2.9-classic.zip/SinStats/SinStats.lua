----------------------
-- SinStats Classic --
----------------------

local AddName, AddonTable = ...
local addVer = "2.9"

-- Global stats initialization
local labelSpellCrit = ""
local labelHit = ""
local speedColor = ""
local hitMod = 0
local spellCritMod = 0
local silithyst = 0
local dmfbuff = 0
local className, classFilename, classId = UnitClass("player") 
local playerLevel = UnitLevel("player")
local headerHeight = 15
local weaponTag = "Weapon"
local headerLoc = "Weapon Skills"
local defenseLoc = DEFENSE
-- Mage
local arcaneMod = 0
local aiMod = 0
local arcaneFocus = 0
local combustionCount = 0
local firepowerMod = 0
local apFire = 0
local pierceMod = 0
local apFrost = 0
local arcanePower = 0
-- Shaman
local emberstorm = 0
local purification = 0
-- Paladin
local vengeance = 0
local wisTalent = 0
local sancAura = 0
-- Warlock
local dsImp = 0
local dsSuc = 0
local shadowMastery = 0
-- Priest
local shadowFormDmg = 0
local spiritualHealing = 0
local DarkNessTalent = 0


if (GetLocale() == "frFR") then
	headerLoc = "Compétences d’armes"
	defenseLoc = DEFENSE
	weaponTag = "Arme"
elseif (GetLocale() == "esES") then
	weaponTag = "Arma"
	headerLoc = "Habilidades con armas"
	defenseLoc = DEFENSE	
elseif (GetLocale() == "deDE") then
	weaponTag = "Waffe"
	headerLoc = "Waffenfertigkeiten"
	defenseLoc = DEFENSE		
elseif (GetLocale() == "itIT") then
	weaponTag = "Arma"
	headerLoc = "Abilità con le armi"
	defenseLoc = DEFENSE		
elseif (GetLocale() == "ruRU") then
	weaponTag = "Oружие"
	headerLoc = "Оружейные навыки"
	defenseLoc = DEFENSE		
elseif (GetLocale() == "ptBR") then
	weaponTag = "Arma"
	headerLoc = "Weapon Skills"
	defenseLoc = DEFENSE	
elseif (GetLocale() == "zhCN") then
	headerLoc = "武器技能"
	defenseLoc = DEFENSE	
elseif (GetLocale() == "koKR") then
	headerLoc = "무기 기술"
	defenseLoc = "방어"	
elseif (GetLocale() == "zhTW") then
	headerLoc = "武器技能"
	defenseLoc = DEFENSE		
else 
	weaponTag = "Weapon"
	headerLoc = "Weapon Skills"
	defenseLoc = DEFENSE	
end

AddonTable.DisplayOrder = {
	{ hud="AP", init=true, grp=1, text="AP: ", textShort="AP: ", spell=6673, },
	{ hud="APud", init=true, grp=1, text="AP UD: ", textShort="UP: ",  spell=17926, },	
	{ hud="RAP", init=true, grp=2, text="rAP: ", textShort="rAP: ",  spell=19506, },
	{ hud="RAPud", init=false, grp=2, text="rAP UD: ", textShort="rUP: ",  spell=5502, },	
	{ hud="DMG", init=true, grp=1, text="DMG: ", textShort="DMG: ", spell=12328, },
	{ hud="RDMG", init=false, grp=2, text="rDMG: ", textShort="rDMG: ", spell=19434, },
	{ hud="Fire", init=false, grp=3, text="Fire: +", textShort="FIR: +", spell=11366, },	
	{ hud="Frost", init=false, grp=3, text="Frost: +", textShort="FRO: +", spell=10181, },	
	{ hud="Arcane", init=false, grp=3, text="Arcane: +", textShort="ARC: +", spell=5143, },
	{ hud="Shadow", init=false, grp=3, text="Shadow: +", textShort="SHA: +", spell=686, },		
	{ hud="Nature", init=false, grp=3, text="Nature: +", textShort="NAT: +", spell=16901, },
	{ hud="Healing", init=true, grp=3, text="Healing: +", textShort="HEAL: +", spell=139, },
	{ hud="Holy", init=false, grp=3, text="Holy: +", textShort="HOL: +",  spell=7294, },		
	{ hud="spellUD", init=false, grp=3, text="Undead: +", textShort="UD: +", spell=17959, },		
	{ hud="Crit", init=true, grp=1, text="Crit: ", textShort="CRIT: ", spell=1719, }, 
	{ hud="CritCap", init=true, grp=1, text="Crit Cap: ", textShort="CAP: ", spell=30920, }, 	
	{ hud="RangedCrit", init=false, grp=2, text="rCrit: ", textShort="rCRIT: ", spell=24395, },
	{ hud="SpellCrit", init=false, grp=3, text="Spell Crit: ", textShort="sCRIT: ", spell=11115, },
	{ hud="Hit", init=true, grp=1, text="Hit: ", textShort="HIT: ", spell=14294, },
	{ hud="RangedHit", init=false, grp=2, text="rHit: ", textShort="rHIT: ", spell=1130, },
	{ hud="SpellHit", init=false, grp=3, text="Spell Hit: ", textShort="sHIT: ", spell=11160, },	
	{ hud="HasteMelee", init=true, grp=1, text="Haste: ", textShort="HAS: ", spell=6774, },
	{ hud="weaponSpeed", init=false, grp=1, text="AS: ", textShort="AS: ", spell=12974, },	
	{ hud="HasteRanged", init=false, grp=2, text="rHaste: ", textShort="rHAS: ", spell=6150, },	
	{ hud="rangedSpeed", init=false, grp=2, text="rAS: ", textShort="rAS: ", spell=3045, },		
	{ hud="HasteCaster", init=false, grp=3, text="Spell Haste: ", textShort="sHAS: ", spell=12042, },	
	{ hud="MeleeMiss", init=false, grp=1, text="Miss: " , textShort="MIS: ", spell=13807, },
	{ hud="MeleeBoss", init=false, grp=1, text="Miss+: ", textShort="MIS+: ", spell=13852, },
	{ hud="RangedMiss", init=false, grp=2, text="rMiss: ", textShort="rMIS: ", spell=19151, },
	{ hud="RangedBoss", init=false, grp=2, text="rMiss+: ", textShort="rMIS+: ", spell=24295, },
	{ hud="SpellMiss", init=false, grp=3, text="Spell Miss: ", textShort="sMIS: ", spell=15060, },
	{ hud="SpellBoss", init=false, grp=3, text="Spell Miss+: ", textShort="sMIS+: ", spell=20484, },	
	{ hud="ManaRegen", init=true, grp=3, text="Mana Regen: ", textShort="MP2: ", spell=14752, },
	{ hud="CastingRegen", init=true, grp=3, text="Casting Regen: ", textShort="MP2+: ", spell=724, },
	{ hud="MP5Cast", init=true, grp=3, text="MP5: ", textShort="MP5: ", spell=19742, },
	{ hud="Armor", init=false, grp=1, text="Armor: ", textShort="ARM: ", spell=12962, },
	{ hud="DMGReduc", init=false, grp=1, text="Mitigation: ", textShort="MIT: ", spell=16301, },
	{ hud="Defense", init=false, grp=1, text="Defense: ", textShort="DEF: ", spell=12753, },
	{ hud="Dodge", init=false, grp=1, text="Dodge: ", textShort="DOD: ", spell=24297, },
	{ hud="Parry", init=false, grp=1, text="Parry: ", textShort="PAR: ", spell=3127, },
	{ hud="Block", init=false, grp=1, text="Block: ", textShort="BLO: ", spell=2565, },
	{ hud="FireResist", init=false, grp=4, text="Fire Res: ", textShort="FR: ", spell=18459, },
	{ hud="FrostResist", init=false, grp=4, text="Frost Res: ", textShort="FrR: ", spell=10161, },
	{ hud="ShadowResist", init=false, grp=4, text="Shadow Res: ", textShort="SR: ", spell=10958, },
    { hud="ArcaneResist", init=false, grp=4, text="Arcane Res: ", textShort="AR: ", spell=1449, },	
	{ hud="NatureResist", init=false, grp=4, text="Nature Res: ", textShort="NR: ", spell=9858, },  	
	{ hud="Speed", init=true, grp=5, text="Speed: ", textShort="SPE: ", spell=2983, },
	{ hud="Durability", init=true, grp=5, text="Durability: ", textShort="DUR: ", spell=3100, },
	{ hud="Lag", init=false, grp=5, text="Ping: ", textShort="LAG: ", spell=1265, },
	{ hud="FPS", init=false, grp=5, text="FPS: ", textShort="FPS: ", spell=19498, },
}

----------------------
-- Initialize Icons --
----------------------
for i=1, #AddonTable.DisplayOrder do
	AddonTable.DisplayOrder[i].icon = "|T"..select(3, GetSpellInfo(AddonTable.DisplayOrder[i].spell))..":0|t"
end

--------------------------------
-- Event Update Function
--------------------------------
function AddonTable:RunAllEvents()
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UPDATE_INVENTORY_DURABILITY")
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_RESISTANCES")   
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_ATTACK_POWER")
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_RANGED_ATTACK_POWER")
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_DAMAGE")  
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_RANGEDDAMAGE")   
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_DEFENSE")  
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_STATS")       
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_AURA") 
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "CHARACTER_POINTS_CHANGED")
end

----------------------------------
-- SavedVariable Initialisation --
----------------------------------
local function initSinStatsDB()
	if not SinStatsDB then
		SinStatsDB = {
			SinLockVar = false,
			SinHideVar = false,
			StatDirection = false,
			IconVar = true,
			StatFontSize = 12,	
			SinOutline = false,
			SinMinimap = false,
			SinAbrev = false,
			Stats = {},
		}
	end	
	for i=1, #AddonTable.DisplayOrder do
		if SinStatsDB.Stats[AddonTable.DisplayOrder[i].hud] == nil then
			SinStatsDB.Stats[AddonTable.DisplayOrder[i].hud] = AddonTable.DisplayOrder[i].init
		end
	end
	if not SinStatsDB.StatFontSize then
		SinStatsDB.StatFontSize = 12
	end
	if not SinStatsDB.minimap then
        SinStatsDB.minimap = {
            hide = false,
        }	
	end	

-------------
-- Minimap --
-------------
local DBObject = LibStub("LibDataBroker-1.1"):NewDataObject("SinStats", {
	type = "data source",
	text = "SinStats",
	icon = "Interface\\Icons\\Inv_weapon_shortblade_37",
	
	OnTooltipShow = function(tooltip)
		tooltip:SetText("|cff0489d1SinStats|r")
		tooltip:AddLine("Click to |cffFFF468Open/Close|r the settings", 1, 1, 1)
		tooltip:Show()
	end,
	
	OnClick = function(self, button, down) 
		AddonTable:ToggleConfig()
	end,
})
AddonTable.sshMiniButton = LibStub("LibDBIcon-1.0")		
AddonTable.sshMiniButton:Register("SinStats", DBObject, SinStatsDB.minimap)	
end
	 
---------------------------
-- Local Helper Function --
---------------------------
local function shapeshitCheck()
	if (classFilename == "DRUID") then
		local index = GetShapeshiftForm()
		if (index == 1) or (index == 3) then
			return true
		else
			return false
		end
	end
end 

-----------------
-- Stat update --
-----------------
local StatsFontSize = 12
local function SetFont(self)
	if not SinStatsDB.OutlineVar then
		self:SetFont("Fonts/ARIALN.ttf", StatsFontSize, "OUTLINE")
	else
		self:SetFont("Fonts/ARIALN.ttf", StatsFontSize, "THICKOUTLINE")
	end
end

local function CreateStatDisplay(parent, name, id)
	local f = parent:CreateFontString("$parent"..name, "OVERLAY", "GameFontNormal")
	f.ID = id
	SetFont(f)
	f:SetTextColor(1,1,1,1)
	parent.Stats[name] = f
	f:SetShown(SinStatsDB.Stats[name])
end

-----------------
-- Stats frame --
-----------------
local f = CreateFrame("frame", "SinStatsFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate")
f:SetBackdrop({
    bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
    tile=1, tileSize=0, edgeSize=0,
})
f:SetBackdropColor(1,1,1,1)
f:SetWidth(200)
f:SetHeight(headerHeight)
f:SetPoint("CENTER",UIParent)
f:SetMovable(true)
f:SetUserPlaced(true)
f:SetClampedToScreen(false)
f:RegisterForDrag("LeftButton")
f:SetScript("OnDragStart", function(self) self:StartMoving() end)
f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
f:SetFrameStrata("BACKGROUND")
f.DragText = f:CreateFontString(nil, "OVERLAY");
f.DragText:SetFontObject("GameFontHighlight");
f.DragText:SetTextColor(1, 1, 1)
f.DragText:SetText("SinStats")
f.DragText:SetPoint("CENTER")

f.Stats = {}
function f:ResizeStats()
	StatsFontSize = SinStatsDB.StatFontSize
	for k, v in pairs(self.Stats) do
		SetFont(v)
	end
end

local function AnchorStat(stat, horizontal, first, last)
	stat:ClearAllPoints()
	if not first then
		stat:SetPoint("TOPLEFT", 0, -headerHeight)
	else
		if horizontal then
			stat:SetPoint("LEFT", last, "RIGHT", 7, 0)	
		else
			stat:SetPoint("TOPLEFT", last, "BOTTOMLEFT")
		end				
	end
	return true, stat
end

local rowList = {}
function f:RedrawStats()
    local first, last
    local horizontal = SinStatsDB.SinDirection
    local rows = SinStatsDB.StatRows or 1
    table.wipe(rowList)
    if not SinStatsDB.GroupOrder then
        for i=1, #AddonTable.DisplayOrder do
            local k = AddonTable.DisplayOrder[i].hud
            local v = self.Stats[k]
            if v:IsShown() then
                if not horizontal or rows == 1 then
                    first, last = AnchorStat(v, horizontal, first, last)
                else        
                    tinsert(rowList, v)
                end
            end
        end
    else
        for i=1, #AddonTable.Groups do
            for n=1, #AddonTable.DisplayOrder do
                if AddonTable.DisplayOrder[n].grp == i then
                    local k = AddonTable.DisplayOrder[n].hud
                    local v = self.Stats[k]
                    if v:IsShown() then
                        if not horizontal or rows == 1 then
                            first, last = AnchorStat(v, horizontal, first, last)
                        else        
                            tinsert(rowList, v)
                        end
                    end
                end
            end
        end
    end
    if horizontal and rows > 1 then
        local totalRows = #rowList
        local maxOnRow = math.floor(totalRows / rows)
        local first, last
        for i=1, totalRows do
            if not first then
                AnchorStat(rowList[i], horizontal, first, last)
                first = rowList[i]
                last = first
            else
                rowList[i]:ClearAllPoints()
                if horizontal then 
                    rowList[i]:SetPoint("LEFT", last, "RIGHT", 7, 0)
                else
                    rowList[i]:SetPoint("TOPLEFT", last, "BOTTOMLEFT", 0, -5)
                end
--              AnchorStat(rowList[i], horizontal, first, last)
                last = rowList[i]
                horizontal = true
            end
            if mod(i, maxOnRow) == 0 then
                last = first
                first = rowList[i+1]
                horizontal = nil
            end
        end
    end
end

--------------------
-- Stat execution --
--------------------
local updatespeed = 1.2
local TimeToNextUpdate = updatespeed

local function SetText(self, parent, text)
	local Icon = parent.AddIcons and AddonTable.DisplayOrder[self.ID].icon or ""
	if SinStatsDB.SinAbrev then
		self:SetText(Icon..AddonTable.DisplayOrder[self.ID].textShort..text) 
	else 
		self:SetText(Icon..AddonTable.DisplayOrder[self.ID].text..text)
	end
end

local function OnUpdate(self, elapsed)

TimeToNextUpdate = TimeToNextUpdate - elapsed
if TimeToNextUpdate > 0 then return end
TimeToNextUpdate = updatespeed

------------------------Armor------------------------
local base, effectiveArmor, armor, posBuff, negBuff = UnitArmor("player");
SetText(self.Stats.Armor, self, effectiveArmor)
-----------------------------------------------------

---------------------Mitigation----------------------
local base, effectiveArmor, armor, posBuff, negBuff = UnitArmor("player");
local armorReduction = effectiveArmor/((85 * playerLevel) + 400);
armorReduction = 100 * (armorReduction/(armorReduction + 1));
SetText(self.Stats.DMGReduc, self, ("%.0f"):format(armorReduction) .. "%")
-----------------------------------------------------

----------------------Melee Crit---------------------
local critChance = GetCritChance("player")
SetText(self.Stats.Crit, self, ("%.2f"):format(critChance) .. "%")
-----------------------------------------------------

----------------------Spell Crit---------------------
local critSpellChance = GetSpellCritChance("player")
critSpellChance = critSpellChance + combustionCount + arcaneMod + spellCritMod
SetText(self.Stats.SpellCrit, self, ("%.2f"):format(critSpellChance) .. "%")
-----------------------------------------------------

----------------------Ranged Crit--------------------
local critRangedChance = GetRangedCritChance("player")
SetText(self.Stats.RangedCrit, self, ("%.2f"):format(critRangedChance) .. "%")
-----------------------------------------------------

-----------------------Melee Hit---------------------
local hitChance = GetHitModifier("player")
SetText(self.Stats.Hit, self, hitChance .. "%")
-----------------------------------------------------

---------------------Attack Speed--------------------
local mainSpeed, offSpeed = UnitAttackSpeed("player")
if offSpeed == nil then
	offSpeed = ""
else
	offSpeed = " / " .. ("%.1f"):format(offSpeed)
end
SetText(self.Stats.weaponSpeed, self, ("%.1f"):format(mainSpeed) .. offSpeed)
-----------------------------------------------------

---------------------Ranged Speed--------------------	
local speed = UnitRangedDamage("player");
SetText(self.Stats.rangedSpeed, self,  ("%.1f"):format(speed));  
-----------------------------------------------------

----------------------Melee Miss---------------------	
local meleeSameLevel = 0
local meleeBossLevel = 0
local mainBase, mainMod, offBase, offMod = UnitAttackBothHands("player")
local levelDefense = playerLevel * 5
local bossDefense = (playerLevel + 3) * 5
local mWeaponSkill = (mainBase + mainMod)
--local shieldEquipped = IsEquippedItemType("Shields")
local mhID = GetInventoryItemID("player", 16);	
local ohID = GetInventoryItemID("player", 17);
	
local mWepSkill = mWeaponSkill
if mWeaponSkill < 300 then 
	mWepSkill = 300 
end				

local meleeSkillDiff = levelDefense - mWeaponSkill
local bossSkillDiff = bossDefense - mWeaponSkill
local bossSkillMod = bossDefense - mWepSkill
local missMod = 0
local missModboss = 0	

missModboss = meleeBossLevel
	
if ohID then 
	_,_,_,_,_,itemType = GetItemInfo(ohID) 
end    

if (mhID and (ohID and itemType == weaponTag)) or (not mhID and (itemType == weaponTag)) then
	if (classFilename == "WARRIOR") or (classFilename == "ROGUE") or (classFilename == "HUNTER") then
		if meleeSkillDiff > 10 then
			meleeSameLevel = (26 + ((meleeSkillDiff - 10) * 0.4))
			meleeSameLevel = meleeSameLevel - hitChance
		elseif meleeSkillDiff <= 10 then
			meleeSameLevel = (24 + ((meleeSkillDiff) * 0.1))
			meleeSameLevel = meleeSameLevel - hitChance		
		end
		
		if bossSkillDiff > 10 then
			meleeBossLevel = (26 + ((bossSkillDiff - 10) * 0.4))
			meleeBossLevel = meleeBossLevel - hitChance
			missMod = (26 + ((bossSkillMod - 10) * 0.4))
			missMod = missMod - hitChance
		elseif bossSkillDiff <= 10 then
			meleeBossLevel = (24 + ((bossSkillDiff) * 0.1))
			meleeBossLevel = meleeBossLevel - hitChance   	
			missMod = (26 + ((bossSkillMod - 10) * 0.4))
			missMod = missMod - hitChance				
		end
	end	
		
elseif (mhID and (ohID and itemType ~= weaponTag)) or (not mhID and (itemType ~= weaponTag)) or (mhID and not ohID) or (not mhID and not ohID) then
	if shapeshitCheck() then
		meleeSameLevel = 5 - hitChance
		meleeBossLevel = 9 - hitChance
	else
		if meleeSkillDiff > 10 then
			meleeSameLevel = (7 + ((meleeSkillDiff - 10) * 0.4))
			meleeSameLevel = meleeSameLevel - hitChance
		elseif meleeSkillDiff <= 10 then
			meleeSameLevel = (5 + ((meleeSkillDiff) * 0.1))
			meleeSameLevel = meleeSameLevel - hitChance		
		end

		if bossSkillDiff > 10 then
			meleeBossLevel = (7 + ((bossSkillDiff - 10) * 0.4))
			meleeBossLevel = meleeBossLevel - hitChance  
			missMod = (7 + ((bossSkillMod - 10) * 0.4))
			missMod = missMod - hitChance					
		elseif bossSkillDiff <= 10 then
			meleeBossLevel = (5 + ((bossSkillDiff) * 0.1))
			meleeBossLevel = meleeBossLevel - hitChance   	
			missMod = (5 + ((bossSkillMod - 10) * 0.1))
			missMod = missMod - hitChance					
		end		
	end	
	
end
	
if meleeSameLevel < 0 then
	meleeSameLevel = 0
elseif meleeSameLevel > 100 then
	meleeSameLevel = 100
end
if meleeBossLevel < 0 then
	meleeBossLevel = 0
elseif meleeBossLevel > 100 then
	meleeBossLevel = 100
end
SetText(self.Stats.MeleeMiss, self, meleeSameLevel .. "%");
SetText(self.Stats.MeleeBoss, self, meleeBossLevel .. "%");
-----------------------------------------------------
	
	
-----------------------Crit Cap----------------------
if ohID and itemType == weaponTag then 
	mWepSkill = math.min((mainBase + mainMod), (offBase + offMod)) 
end	

local skillDiff = 315 - mWepSkill
local critSupp = 4.8	
local dodgeBoss = 5 + (skillDiff * 0.1)
local glancingBoss = 40	
local extraWeaponSkill = mWepSkill - 300	
local mcritCap = 100 - missMod - dodgeBoss - glancingBoss + critSupp + (extraWeaponSkill * 0.04)

if critChance > mcritCap then
	critCapColor = "|cffC41E3A"
elseif critChance == mcritCap then
	critCapColor = "|cffFF7C0A"
else
	critCapColor = "|cff00f26d"
end

if mcritCap > 100 then
	mcritCap = 100
end

SetText(self.Stats.CritCap, self, critCapColor .. ("%.1f"):format(mcritCap) .. "%" .. "|r")	
-----------------------------------------------------

----------------------Ranged Hit---------------------
local label, hitRangedChance, percentAdded = "rHit: ", 0, ""
if (classFilename == "HUNTER") then
	local slotId = GetInventorySlotInfo("RangedSlot")
	local link = GetInventoryItemLink("player", slotId)
	if link then
		hitRangedChance = GetHitModifier("player");
		local itemId, enchantId = link:match("item:(%d+):(%d+)")
		if enchantId then
			enchantId = tonumber(enchantId)
			if enchantId == 2523 then
				hitRangedmod = 3
				hitRangedChance = hitRangedChance + 3
			end
		end
	end	
	SetText(self.Stats.RangedHit, self, (hitRangedChance and hitRangedChance) .. "%"); 
else
	hitRangedChance = GetHitModifier("player");
	SetText(self.Stats.RangedHit, self, hitRangedChance .. "%"); 
end
-----------------------------------------------------

----------------------Ranged Miss--------------------
local rangedMissLevel = 0
local rangedMissBoss = 0
local rangedAttackBase, rangedAttackMod = UnitRangedAttack("player")
local levelDefense = playerLevel * 5
local bossDefense = (playerLevel + 3) * 5
local rWeaponSkill = (rangedAttackBase + rangedAttackMod)
local rangedSkillDiff = levelDefense - rWeaponSkill
local rbossSkillDiff = bossDefense - rWeaponSkill	


if rangedSkillDiff > 10 then	
	rangedMissLevel = (7 + ((rangedSkillDiff - 10) * 0.4))
	rangedMissLevel = rangedMissLevel - hitRangedChance	
elseif meleeSkillDiff <= 10 then	
	rangedMissLevel = (5 + ((rangedSkillDiff) * 0.1))
	rangedMissLevel = rangedMissLevel - hitRangedChance
end

if rbossSkillDiff > 10 then
	rangedMissBoss = (7 + ((rbossSkillDiff - 10) * 0.4))
	rangedMissBoss = rangedMissBoss - hitRangedChance	
elseif rbossSkillDiff <= 10 then
	rangedMissBoss = (5 + ((rbossSkillDiff) * 0.1))
	rangedMissBoss = rangedMissBoss - hitRangedChance	
end 

if rangedMissLevel < 0 then
	rangedMissLevel = 0
elseif rangedMissLevel > 100 then
	rangedMissLevel = 100
end
SetText(self.Stats.RangedMiss, self, rangedMissLevel .. "%")	

if rangedMissBoss < 0 then
	rangedMissBoss = 0
elseif rangedMissBoss > 100 then
	rangedMissBoss = 100
end
SetText(self.Stats.RangedBoss, self, rangedMissBoss .. "%|r")
-----------------------------------------------------

-----------------------Spell Hit---------------------
local hitSpellChance = GetSpellHitModifier("player")
hitSpellChance = hitSpellChance + hitMod
SetText(self.Stats.SpellHit, self, hitSpellChance .. "%" .. labelHit)
-----------------------------------------------------

-----------------------Spell Miss--------------------
local spellSameLevel = 3
local spellBossLevel = 16
spellSameLevel = (spellSameLevel - hitSpellChance)
spellBossLevel = (spellBossLevel - hitSpellChance)
if spellSameLevel < 0 then
	spellSameLevel = 0
elseif spellSameLevel > 100 then
	spellSameLevel = 100
end
if spellBossLevel < 0 then
	spellBossLevel = 0
elseif spellBossLevel > 100 then
	spellBossLevel = 100
end
SetText(self.Stats.SpellMiss, self, spellSameLevel .. "%")
SetText(self.Stats.SpellBoss, self, spellBossLevel .. "%")
-----------------------------------------------------

-----------------------Healing-----------------------
local SinHealSpell = GetSpellBonusHealing();
SinHealSpell = SinHealSpell + (SinHealSpell * spiritualHealing) + (SinHealSpell * purification)
SetText(self.Stats.Healing, self, ("%.0f"):format(SinHealSpell))
-----------------------------------------------------

------------------------Holy-------------------------
local SinHolySpell = GetSpellBonusDamage(2);
SinHolySpell = (SinHolySpell + (SinHolySpell * dmfbuff) + (SinHolySpell * silithyst) + (SinHolySpell * sancAura) + (SinHolySpell * vengeance))
SetText(self.Stats.Holy, self, ("%.0f"):format(SinHolySpell))
-----------------------------------------------------

------------------------Nature-----------------------
local SinNatureSpell = GetSpellBonusDamage(4);
SinNatureSpell = (SinNatureSpell + (SinNatureSpell * dmfbuff) + (SinNatureSpell * silithyst))  
SetText(self.Stats.Nature, self, SinNatureSpell)
-----------------------------------------------------

-----------------------Shadow-----------------------
local SinShadowSpell = GetSpellBonusDamage(6);
SinShadowSpell = (SinShadowSpell + (SinShadowSpell * shadowMastery) + (SinShadowSpell * DarkNessTalent) + (SinShadowSpell * dsSuc))
SinShadowSpell = (SinShadowSpell + (SinShadowSpell * dmfbuff) + (SinShadowSpell * silithyst) + (SinShadowSpell * shadowFormDmg))
SetText(self.Stats.Shadow, self, ("%.0f"):format(SinShadowSpell))
-----------------------------------------------------      

------------------------Fire-------------------------
local SinFireSpell = GetSpellBonusDamage(3);    
SinFireSpell = (SinFireSpell + (SinFireSpell * firepowerMod) + (SinFireSpell * aiMod) + firepowerMod + (SinFireSpell * emberstorm) + (SinFireSpell * dsImp))
SinFireSpell = (SinFireSpell + (SinFireSpell * dmfbuff) + (SinFireSpell * silithyst) + (SinFireSpell * arcanePower))
SetText(self.Stats.Fire, self, ("%.0f"):format(SinFireSpell))
-----------------------------------------------------   

------------------------Frost-----------------------
local SinFrostSpell = GetSpellBonusDamage(5);               
SinFrostSpell = (SinFrostSpell + (SinFrostSpell * pierceMod) + (SinFrostSpell * aiMod))          
SinFrostSpell = (SinFrostSpell + (SinFrostSpell * dmfbuff) + (SinFrostSpell * silithyst) + (SinFrostSpell * arcanePower))
SetText(self.Stats.Frost, self, ("%.0f"):format(SinFrostSpell))
----------------------------------------------------- 

-----------------------Arcane-----------------------
local SinArcaneSpell = GetSpellBonusDamage(7);
SinArcaneSpell = (SinArcaneSpell + (SinArcaneSpell * aiMod))
SinArcaneSpell = (SinArcaneSpell + (SinArcaneSpell * dmfbuff) + (SinArcaneSpell * silithyst) + (SinArcaneSpell * arcanePower))
SetText(self.Stats.Arcane, self, ("%.0f"):format(SinArcaneSpell))
-----------------------------------------------------

------------------------Dodge------------------------
local dodgeChance = GetDodgeChance("player");
SetText(self.Stats.Dodge, self, ("%.2f"):format(dodgeChance) .. "%")
----------------------------------------------------- 

------------------------Parry------------------------
local parryChance = GetParryChance("player");
SetText(self.Stats.Parry, self, ("%.2f"):format(parryChance) .. "%")
-----------------------------------------------------

------------------------Block------------------------
local blockChance = GetBlockChance("player");
SetText(self.Stats.Block, self, ("%.2f"):format(blockChance) .. "%")  
-----------------------------------------------------

------------------------Speed------------------------
local currentSpeed, runSpeed, flightSpeed, swimSpeed = GetUnitSpeed("player")
local fullSpeed = GetUnitSpeed("player") / 7 * 100
if fullSpeed == 0 or fullSpeed == 100 then
	speedColor = ""
elseif fullSpeed < 100 then
	speedColor = "|cffC41E3A"
elseif fullSpeed > 100 then
	speedColor = "|cff00f26d"
end
SetText(self.Stats.Speed, self, speedColor .. string.format("%d%%", ("%.0f"):format(fullSpeed)))
-----------------------------------------------------

-------------------------FPS-------------------------
local framerate = GetFramerate()
if framerate < 30 then
	SetText(self.Stats.FPS, self, "|cffC41E3A" .. floor(framerate) .. "|r")
elseif framerate > 30 and framerate < 50 then
	SetText(self.Stats.FPS, self, "|cffFF7C0A" .. floor(framerate) .. "|r")
elseif framerate > 50 then
	SetText(self.Stats.FPS, self, "|cff00f26d" .. floor(framerate) .. "|r")
end
-----------------------------------------------------

-------------------------Lag-------------------------
local _, _, _, lagWorld = GetNetStats();
if lagWorld < 90 then
	SetText(self.Stats.Lag, self, "|cff00f26d" .. lagWorld .. " ms|r"); 
elseif lagWorld >= 90 and lagWorld < 200 then
	SetText(self.Stats.Lag, self, "|cffFF7C0A" .. lagWorld .. " ms|r"); 
elseif lagWorld > 200 then
	SetText(self.Stats.Lag, self, "|cffC41E3A" .. lagWorld .. " ms|r"); 
end
-----------------------------------------------------

------------------------Undead-----------------------
local udTrinket = 0
local markTrinket = 0
local mhEnchant = 0
local ohEnchant = 0
local slayerSet = 0
local trinketCheck = GetInventoryItemID("player", 13);	
local trinketCheck2 = GetInventoryItemID("player", 14);	
local glovesCheck = GetInventoryItemID("player", 10);	
local bracersCheck = GetInventoryItemID("player", 9);		
local chestCheck = GetInventoryItemID("player", 5);		
local _, _, _, mainHandEnchantID, _, _, _, offHandEnchantId  = GetWeaponEnchantInfo()
if trinketCheck == 13209 or trinketCheck2 == 13209 then
	udTrinket = 81
end
if trinketCheck == 23206 or trinketCheck2 == 23206 then
	markTrinket = 150
end
if (mainHandEnchantID == 2684) then
	mhEnchant = 100
end
if (offHandEnchantId == 2684) then
	ohEnchant = 100
end		
if glovesCheck == 23078 or glovesCheck == 23081 then
	slayerSet = slayerSet + 60
end
if bracersCheck == 23093 or bracersCheck == 23090 then
	slayerSet = slayerSet + 45
end
if chestCheck == 23087 or chestCheck == 23089 then
	slayerSet = slayerSet + 81
end		

local base, posBuff, negBuff = UnitAttackPower("player");
local undeadAP = base + posBuff + negBuff + mhEnchant + ohEnchant + udTrinket + markTrinket;	
local base, posBuff, negBuff = UnitRangedAttackPower("player");
local undeadrAP = base + posBuff + negBuff + mhEnchant + ohEnchant + udTrinket + markTrinket;	
SetText(self.Stats.APud, self, undeadAP + slayerSet)
SetText(self.Stats.RAPud, self, undeadrAP + slayerSet)	
-----------------------------------------------------

	
---------------------Undead Spell--------------------
local undeadSpell = 0
local cleansingSet = 0
if trinketCheck == 19812 or trinketCheck2 == 19812 then
	udTrinket = 48
end
if trinketCheck == 23207 or trinketCheck2 == 23207 then
	markTrinket = 85
end
if (mainHandEnchantID == 2685) then
	mhEnchant = 60
end
if (offHandEnchantId == 2685) then
	ohEnchant = 60
end		
if glovesCheck == 23084 then
	cleansingSet = cleansingSet + 35
end
if bracersCheck == 23091 then
	cleansingSet = cleansingSet + 26
end
if chestCheck == 23085 then
	cleansingSet = cleansingSet + 48
end			

spellTable = {SinFrostSpell, SinFireSpell, SinArcaneSpell, SinShadowSpell, SinNatureSpell, SinHolySpell}
table.sort(spellTable)
undeadSpell = spellTable[#spellTable]

SetText(self.Stats.spellUD, self, format("%.0f", undeadSpell + udTrinket + markTrinket + mhEnchant + ohEnchant + cleansingSet))	
-----------------------------------------------------

end

------------------Talents Scanner--------------------
local function talentScan()
	local className, classFilename, classId = UnitClass("player")
	if (classFilename == "MAGE") then  
	
		local _, _, _, _, points, _, _, _ = GetTalentInfo(2, 13)
				spellCritMod = (points * 2)
				
		local _, _, _, _, points, _, _, _ = GetTalentInfo(1, 15)
				arcaneMod = points * 1
				aiMod = ((points * 1)/100)

		local _, _, _, _, points, _, _, _ = GetTalentInfo(3, 3)
				hitMod = points * 2

		local _, _, _, _, points, _, _, _ = GetTalentInfo(1, 2)
				arcaneFocus = points * 2
				if arcaneFocus > 0 then
				labelHit = (" (|cff69CCF0+" .. ("%.0f"):format(arcaneFocus) .. "|r)") 
				end
   
		local _, _, _, _, points, _, _, _ = GetTalentInfo(2, 15)      
				firepowerMod = ((points * 2)/100)
    
		local _, _, _, _, points, _, _, _ = GetTalentInfo(3, 8)
				pierceMod = ((points * 2) / 100)

	elseif (classFilename == "PRIEST") then
	
		local _, _, _, _, points, _, _, _ = GetTalentInfo(2, 3)
				spellCritMod = points * 1
				--labelSpellCrit = (" (|cffedede6+" .. ("%.0f"):format(spellCritMod) .. "|r)")

		local _, _, _, _, points, _, _, _ = GetTalentInfo(3, 5)
				hitMod = points * 2
				if hitMod > 0 then
				labelHit = (" (|cff8787ED+" .. ("%.0f"):format(hitMod) .. "|r)")   
				end

		local _, _, _, _, points, _, _, _ = GetTalentInfo(3, 15)
				DarkNessTalent = ((points * 2) / 100)
   		
		local _, _, _, _, points, _, _, _ = GetTalentInfo(2, 15)   
				spiritualHealing = ((points * 2) / 100)
    

	elseif (classFilename == "PALADIN") then

		local _, _, _, _, points, _, _, _ = GetTalentInfo(1, 10)
				wisTalent = ((points * 10)/100)	

	elseif (classFilename == "WARLOCK") then

		local _, _, _, _, points, _, _, _ = GetTalentInfo(1, 16)
				shadowMastery = ((points * 2)/100)
       
		local _, _, _, _, points, _, _, _ = GetTalentInfo(3, 15)
				emberstorm = ((points * 2)/100)   

	elseif (classFilename == "SHAMAN") then
	
		local _, _, _, _, points, _, _, _ = GetTalentInfo(3, 14)  
				purification = ((points * 2)/100)      

	end 
end
-----------------------------------------------------

-------------------Events----------------------------
f:SetScript("OnEvent", function (self, event, ...)

local spirit, effectiveSpirit, posBuffSpirit, negBuffSpirit = UnitStat("player", 5)
	
if event == "PLAYER_LOGIN" then
	print("|cff0489d1SinStats Classic v" .. addVer .. "|r loaded. Type |cff00c0ff/sinstats|r or |cff00c0ff/ss|r to open the settings.")
	initSinStatsDB()
	self.AddIcons = SinStatsDB.IconVar
	talentScan()
	StatsFontSize = SinStatsDB.StatFontSize
	
	for i=1, #AddonTable.DisplayOrder do
		local Settings = AddonTable.DisplayOrder[i]
		if SinStatsDB and SinStatsDB.Stats[Settings.hud] == nil then
			print("|cffff0000SinsStats:|r Missing Saved Variable:|cff00ff00", Settings.hud)
		else
			CreateStatDisplay(self, Settings.hud, i)
		end
	end
	
	self:ResizeStats()
	self:RedrawStats()
		
	StaticPopupDialogs["SINSTATS_HUD_RESET"] = {
		text = "Reset the HUD's position ?",
		button1 = "Yes",
		button2 = "No",
		timeout = 0,
		whileDead = true,
		hideOnEscape = false,		
		OnAccept = function(self) 
			SinStatsFrame:SetUserPlaced(false)
			SinStatsFrame:ClearAllPoints()
			SinStatsFrame:SetPoint("CENTER", 0, 0)
			SinStatsFrame:SetUserPlaced(true)
		end,
		OnCancel = function(self) end, 
	}
	
	-- Event Registration
	self:RegisterEvent("UNIT_STATS", "player")
	self:RegisterUnitEvent("UNIT_AURA", "player")
	self:RegisterEvent("CHARACTER_POINTS_CHANGED")
	self:RegisterEvent("BIND_ENCHANT")
	self:RegisterEvent("REPLACE_ENCHANT")
	self:RegisterEvent("UPDATE_INVENTORY_DURABILITY")
	self:RegisterUnitEvent("UNIT_RESISTANCES", "player")
	self:RegisterEvent("UNIT_DAMAGE")
	self:RegisterEvent("UNIT_RANGEDDAMAGE")
	self:RegisterEvent("UNIT_ATTACK_POWER")
	self:RegisterEvent("UNIT_RANGED_ATTACK_POWER")
	self:RegisterEvent("UNIT_DEFENSE")
	self:RegisterEvent("PLAYER_LEVEL_UP")

	AddonTable:RunAllEvents()
	AddonTable:UpdateStatus()
	self:SetScript("OnUpdate", OnUpdate)
	
elseif event == "UNIT_DEFENSE" then
	
	local baseDefense = 0
	local bonusDefense = 0
	local DefGearIndex = 0		
	local DefGear = GetNumSkillLines()
	local DefHeader = nil
		
	for i = 1, DefGear do
		local DefName = select(1, GetSkillLineInfo(i))
		local headerCheck = select(2, GetSkillLineInfo(i))
		if headerCheck ~= nil and headerCheck then
			DefHeader = DefName;
		else
			if (DefHeader == headerLoc) and (DefName == defenseLoc) then
				DefGearIndex = i
				break
			end
		end	
	end
	if (DefGearIndex > 0) then
		baseDefense = select(4, GetSkillLineInfo(DefGearIndex))
		bonusDefense = select(6, GetSkillLineInfo(DefGearIndex))
	end
	SetText(self.Stats.Defense, self, format("%.0f", (baseDefense + bonusDefense)))   
		
elseif event == "UNIT_RESISTANCES" then

	local base, bonus, total = UnitResistance("player",2)
	local effectiveFR = bonus
	SetText(self.Stats.FireResist, self, effectiveFR)

	local base, bonus, total = UnitResistance("player",5)
	local effectiveSR = bonus
	SetText(self.Stats.ShadowResist, self, effectiveSR)

	local base, bonus, total = UnitResistance("player",4)
	local effectiveFrR = bonus
	SetText(self.Stats.FrostResist, self, effectiveFrR)
	
	local base, bonus, total = UnitResistance("player",6)
	local effectiveAR = bonus
	SetText(self.Stats.ArcaneResist, self, effectiveAR)  		

	local base, bonus, total = UnitResistance("player",3)
	local effectiveNR = bonus
	SetText(self.Stats.NatureResist, self, effectiveNR)   

elseif event == "UPDATE_INVENTORY_DURABILITY" then
	local Durability, Current, Full, Percent
	local LowestCurrent, LowestFull, t1, t2, t3 = 500, 0, 0, 0, 100
	for i=1,19 do
		Current, Full = GetInventoryItemDurability(i)
		if Current and Full then
			Percent = floor(100*Current/Full + 0.5)
			if (Percent < t3) then
				t3 = Percent
			end
			if (Current < LowestCurrent) then
				LowestCurrent = Current
				LowestFull = Full
			end
			t1 = t1 + Current
			t2 = t2 + Full
		end
	end
	if t2 == 0 then
		Durability = "N/A"
	else
		Durability = floor(t1 * 100 / t2)
	end
	local Text = ""
	if type(Durability) == "number" then
		if Durability > 50 then
			Text = string.format("|cff%2xff00", ((Durability > 50) and (255 - 2.55*Durability) or (2.55*Durability)), Durability) .. Text
		else
			Text = string.format("|cffff%2x00", (2.55*Durability), Durability) .. Text
		end
		Text = Text..Durability.."%"
	end
	SetText(self.Stats.Durability, self, Text)         

elseif event == "UNIT_ATTACK_POWER" then

	local base, posBuff, negBuff = UnitAttackPower("player");
	local effectiveAP = base + posBuff + negBuff;
	SetText(self.Stats.AP, self, effectiveAP); 

elseif event == "UNIT_RANGED_ATTACK_POWER" then

	local base, posBuff, negBuff = UnitRangedAttackPower("player");
	local effectiveRanged = base + posBuff + negBuff;
	SetText(self.Stats.RAP, self, effectiveRanged);

elseif event == "UNIT_DAMAGE" then

	local lowDmg, hiDmg, offlowDmg, offhiDmg, posBuff, negBuff, percentmod = UnitDamage("player");
	local dmgeffect = hiDmg;		
	SetText(self.Stats.DMG, self, ("%.0f"):format(dmgeffect));

elseif event == "UNIT_RANGEDDAMAGE" then

	local speed, lowDmg, hiDmg, posBuff, negBuff, percent = UnitRangedDamage("player");
	local Rdmgeffect = hiDmg;
	SetText(self.Stats.RDMG, self,  ("%.0f"):format(Rdmgeffect));    

elseif event == "CHARACTER_POINTS_CHANGED" then

	talentScan()
	self:RedrawStats()

elseif event == "PLAYER_LEVEL_UP" then
	
	playerLevel = UnitLevel("player")

else
	local base = 0
	
	if (playerLevel < 19) then
		if (classFilename ~= "WARRIOR") and (classFilename ~= "ROGUE") then
			base = ((spirit/2))
		end
	elseif (classFilename == "HUNTER") or (classFilename == "PALADIN") or (classFilename == "WARLOCK") or (classFilename == "SHAMAN") then
		base = ((spirit/5) + 15)
	elseif (classFilename == "PRIEST") or (classFilename == "MAGE") then
		base = ((spirit/4) + 12.5)
	elseif (classFilename == "DRUID") then
		base = ((spirit/5) + 15)
	end 

	local mp5 = 0
	local tierPieces = 0
	local zgPieces = 0 
	local pouchCounter = 0
	local atkspeed = 0	
	local scourgeMp5 = 0
	
	if (classFilename ~= "WARRIOR") and (classFilename ~= "ROGUE") then
		for i=1,23 do
			local itemLink = GetInventoryItemLink("player", i)
			if itemLink then
				local stats = GetItemStats(itemLink)
				local itemId, enchantId = itemLink:match("item:(%d+):(%d+)")
				
					if stats then
						local statMP5 = stats["ITEM_MOD_POWER_REGEN0_SHORT"]
							if (statMP5) then
								mp5 = mp5 + statMP5 + 1
							end
					end
					
					if enchantId then
						enchantId = tonumber(enchantId)
							if enchantId == 2715 then
								scourgeMp5 = 5
							end
					end
					
	if (classFilename == "PRIEST") or (classFilename == "DRUID") or (classFilename == "PALADIN") or (classFilename == "SHAMAN") then
		local itemName = C_Item.GetItemNameByID(GetInventoryItemLink("player", i))
			if itemName then
				if classId == 5 then 
					if string.sub(itemName, -13) == "Transcendence" then
						tierPieces = tierPieces + 1
					end
				elseif classId == 11 then 
					if string.sub(itemName, 1, 9) == "Stormrage" then
						tierPieces = tierPieces + 1
					end
					if (string.sub(itemName, 10, 17) == "Haruspex") or 
						(string.sub(itemName, -15) == "South Seas Kelp") or
						(string.sub(itemName, 1, 9) == "Wushoolay") then
						zgPieces = zgPieces + 1
					end
				elseif classId == 2 then 
					if (string.sub(itemName, 10, 20) == "Freethinker") or 
						(string.sub(itemName, 1, 7) == "Gri'lek") or
						(string.sub(itemName, 1, 12) == "Hero's Brand") then
						zgPieces = zgPieces + 1
					end
				elseif classId == 7 then 
					if (string.sub(itemName, 1, 5) == "Augur") or 
						(string.sub(itemName, 1, 8) == "Unmarred") or
						(string.sub(itemName, 1, 9) == "Wushoolay") then
						zgPieces = zgPieces + 1
					end
					if string.sub(itemName, -14) == "Earthshatterer" then
						tierPieces = tierPieces + 1
					end
				end
			end
	end
	
	if (classFilename == "HUNTER") then
		local itemName = C_Item.GetItemNameByID(GetInventoryItemLink("player", i))
			if itemName then
				if (string.sub(itemName, -10) == "Ammo Pouch") or
					(string.sub(itemName, 1, 10) == "Small Shot") or
					(string.sub(itemName, -9) == "Ammo Sack") or
					(string.sub(itemName, -6) == "Quiver") then
					pouchCounter = 10
				elseif (string.sub(itemName, 1, 9) == "Bandolier") or
						(string.sub(itemName, -11) == "Night Watch") then
						pouchCounter = 11
				elseif (string.sub(itemName, 1, 3) == "Heavy Leather") or
						(string.sub(itemName, 1, 12) == "Heavy Quiver") then
						pouchCounter = 12
				elseif (string.sub(itemName, 1, 13) == "Thick Leather") or
						(string.sub(itemName, 1, 9) == "Quickdraw") then
						pouchCounter = 13
				elseif (string.sub(itemName, 1, 8) == "Ribbly's") then
					pouchCounter = 14
				elseif (string.sub(itemName, 1, 10) == "Gnoll Skin") or 
					(string.sub(itemName, 1, 10) == "Harpy Hide") or
					(string.sub(itemName, -6) == "Lamina") then
					pouchCounter = 15								
				end		        
			end				
	end										
			end
		end
	end 

	local effectiveMR = mp5 * 0.4       
	local talentRegen = 0
	local totemTalent = 0
	
	if (classFilename == "MAGE") then
		local _, _, _, _, points, _, _, _ = GetTalentInfo(1, 12) 
		talentRegen = (((base)/100) * (points * 5))
	elseif (classFilename == "DRUID") then
		local _, _, _, _, points, _, _, _ = GetTalentInfo(3, 6) 
		talentRegen = ((base/100) * (points * 5))
	elseif (classFilename == "PRIEST") then
		local _, _, _, _, points, _, _, _ = GetTalentInfo(1, 8) 
		talentRegen = ((base/100) * (points * 5))
	elseif (classFilename == "SHAMAN") then
		local _, _, _, _, points, _, _, _ = GetTalentInfo(3, 10)
		totemTalent = ((base/100) * (points * 5))
	end 

	local magearmor = 0
	local evoc = 0  
	local felEnergy = 0 
	local siphonregen = 0
	local siphoncast = 0    
	local innerregen = 0
	local innercast = 0
	local bowisdom = 0
	local wismp5 = 0
	local springtotem = 0
	local tidetotem = 0
	local swregen = 0   
	local fishsoup = 0
	local fishsoupmp5 = 0   
	local sageFish = 0
	local warchief = 0
	local mageblood = 0
	local meleeHaste = 100	
	local rangedHaste = 100
	local castHaste = 100
	local epiphany = 0
	local drinkRegen = 0	
	arcanePower = 0
	sancAura = 0
	combustionCount = 0
	shadowFormDmg = 0
	dmfbuff = 0
	silithyst = 0
	vengeance = 0
	local totemicPower = 0
	local tierBonusShield = 0

		
if (classFilename ~= "WARRIOR") and (classFilename ~= "ROGUE") then 
	
	for i = 1, 40 do
		local _, _, count, _, _, _, _, _, _, spellId = UnitBuff("player",i, "HELPFUL")
		if not spellId then break end   

		if spellId == 29166 then 
			innerregen = ((base)*4)
			innercast = base    
		end
		
		if spellId == 16609 then 
			warchief = 10
		end 
		
		if spellId == 25941 then
			sageFish = 6
		end
		
		if spellId == 430 then
			drinkRegen = 16.8
		elseif spellId == 431 then
			drinkRegen = 41.50
		elseif spellId == 432 then
			drinkRegen = 69.6
		elseif spellId == 1133 then
			drinkRegen = 99.5
		elseif spellId == 1135 then
			drinkRegen = 132.8
		elseif spellId == 1137 then
			drinkRegen = 195.6
		elseif spellId == 22734 then
			drinkRegen = 280
		end		
		
		if spellId == 28824 then
			totemicPower = 28
		end
		
		-- wisdom
		if spellId == 19742 then 
			bowisdom = (((10 * wisTalent) * 0.4) + (10 * 0.4))
			wismp5 = ((10 * wisTalent)  + 10)
		elseif spellId == 19850 then 
			bowisdom = (((15 * wisTalent) * 0.4) + (15 * 0.4))
			wismp5 = ((15 * wisTalent)  + 15)   
		elseif spellId == 19852 then
			bowisdom = (((20 * wisTalent) * 0.4) + (20 * 0.4))
			wismp5 = ((20 * wisTalent)  + 20)   
		elseif spellId == 19853 then
			bowisdom = (((25 * wisTalent) * 0.4) + (25 * 0.4))
			wismp5 = ((25 * wisTalent)  + 25)   
		elseif spellId == 19854 then 
			bowisdom = (((30 * wisTalent) * 0.4) + (30 * 0.4))
			wismp5 = ((30 * wisTalent)  + 30)   
		elseif spellId == 25290 then 
			bowisdom = (((33 * wisTalent) * 0.4) + (33 * 0.4))
			wismp5 = ((33 * wisTalent)  + 33)   
		elseif spellId == 25894 then 
			bowisdom = (((30 * wisTalent) * 0.4) + (30 * 0.4))
			wismp5 = ((30 * wisTalent)  + 30)   
		elseif spellId == 25918 then
			bowisdom = (((33 * wisTalent) * 0.4) + (33 * 0.4))
			wismp5 = ((33 * wisTalent)  + 33)	
		
		-- totems
		elseif spellId == 5677 then 
			if totemTalent > 0 then
				springtotem = 4 + totemTalent
			else
				springtotem = 4
			end 
		elseif spellId == 10491 then 
			if totemTalent > 0 then
				springtotem = 6 + totemTalent
			else
				springtotem = 6
			end 
		elseif spellId == 10493 then 
			if totemTalent > 0 then
				springtotem = 8 + totemTalent
			else
				springtotem = 8
			end 
		elseif spellId == 10494 then 
			if totemTalent > 0 then
				springtotem = 10 + totemTalent
			else
				springtotem = 10
			end 
		elseif spellId == 24853 then   
			springtotem = 27
		elseif spellId == 16191 then 
			tidetotem = 114 
		elseif spellId == 17355 then 
			tidetotem = 154 
		end
		
		if spellId == 18194 then 
			fishsoup = (8 * 0.4)
			fishsoupmp5 = 8 
		end
		
		if spellId == 15604 then 
			swregen = 60
		end 
		
		if spellId == 24363 then
			mageblood = 12
		end
		
		if spellId == 23768 then
			dmfbuff = 0.10
		end
		
		if spellId == 29534 then
			silithyst = 0.05
		end
		
		if spellId == 26635 then
			local health = UnitHealth("player")
			local max_health = UnitHealthMax("player")
			local percenthealth = ((health/max_health) * 100)
			if percenthealth > 40 then	
				rangedHaste = (rangedHaste + 10)
				meleeHaste = (meleeHaste + 10)
				castHaste = (castHaste + 10)		
			else 
				rangedHaste = (rangedHaste + 30)
				meleeHaste = (meleeHaste + 30)	
				castHaste = (castHaste + 30)		
			end
		end		

		if spellId == 16322 then 
			meleeHaste = (meleeHaste + 3)
		end		
		
		if spellId == 7396 then 
			meleeHaste = (meleeHaste + 10)
		end		
		
		if spellId == 16609 then 
			meleeHaste = (meleeHaste + 15)
		end		
		
		if spellId == 15167 then 
			meleeHaste = (meleeHaste + 65)
		end		
		
		if spellId == 21165 then 
			meleeHaste = (meleeHaste + 20)
		end				
			
	if (classFilename == "MAGE") then  
	
		if spellId == 28682 then
			combustionCount = count
			combustionCount = combustionCount * 10
		end
		
		if spellId == 6117 or spellId == 22782 or spellId == 22783 then 
			magearmor = ((base)*0.3)
		elseif spellId == 12051 then
			evoc = ((base)*15)
		end	
					
		if spellId == 23723 then
			castHaste = (castHaste + 33)
		end	
		
		if spellId == 12042 then
			arcanePower = 0.3
		end
		
	end
	
	if (classFilename == "WARLOCK") then
	
		local maxpower = UnitPowerMax("player" , mana)
		
		if spellId == 18792 then 
			felEnergy = ((maxpower * 0.02) / 2)
		end
		
		if spellId == 18371 then 
			siphonregen = ((base)*2)
			siphoncast = ((base)/2)     
		end    
		
		if spellId == 18791 then
			dsSuc = 0.15
		end
		
		if spellId == 18789 then
			dsImp = 0.15	
		end
	end 
	
	if (classFilename == "DRUID") then
	
		if shapeshitCheck() then
			if spellId == 16322 then
				meleeHaste = (meleeHaste + 3)
			end		
			
			if spellId == 7396 then
				meleeHaste = (meleeHaste + 10)
			end
			
			if spellId == 16609 then
				meleeHaste = (meleeHaste + 15)
			end	
			
			if spellId == 15167 then 
				meleeHaste = (meleeHaste + 65)
			end	
			
			if spellId == 13494 then 
				meleeHaste = (meleeHaste + 50)
			end
		end
	end

	if (classFilename == "HUNTER") then
		
		if spellId == 3045 then 
			rangedHaste = (rangedHaste + 40)
		end		
		
		if spellId == 6150 then 
			rangedHaste = (rangedHaste + 30)
		end	
		
		if spellId == 28866 then 
			rangedHaste = (rangedHaste + 20)
		end	

	end
	
	if (classFilename == "PALADIN") then
				
		if spellId == 20050 then
			vengeance = 0.03
		elseif spellId == 20052 then
			vengeance = 0.06
		elseif spellId == 20053 then
			vengeance = 0.09
		elseif spellId == 20054 then
			vengeance = 0.12
		elseif spellId == 20055 then
			vengeance = 0.15
		end	
		
		if spellId == 23733 then 
			meleeHaste = (meleeHaste + 25)
			castHaste = (castHaste + 33)
		end		
		
		if spellId == 28866 then 
			meleeHaste = (meleeHaste + 20)
		end	
		
		if spellId == 20218 then	
			sancAura = 0.1
		end
	end
	
	if (classFilename == "PRIEST") then
	
		if spellId == 15473 then
			shadowFormDmg = 0.15
		end
		
		if spellId == 28804 then
			epiphany = 24 
		end	
		
		if spellId == 20218 then
			sancAura = 0.1
		end
	end	
	
	if (classFilename == "SHAMAN") then
		
		if spellId == 28866 then 
			meleeHaste = (meleeHaste + 20)
		end	
		
		if tierPieces >= 8 then
			if spellId == 324 or spellId == 325 or spellId == 905 or spellId == 945 or spellId == 8134 or spellId == 10431 or spellId == 10432 then
				tierBonusShield = 15
			end
		end
		end	
		end
	end

	if (classFilename == "WARRIOR") then
	
		for i = 1, 40 do
			local _, _, _, _, _, _, _, _, _, spellId = UnitBuff("player",i, "HELPFUL")
			if not spellId then break end   
			
			if spellId == 12966 then 
				meleeHaste = (meleeHaste + 10)
			elseif spellId == 12967 then 
				meleeHaste = (meleeHaste + 15)
			elseif spellId == 12968 then 
				meleeHaste = (meleeHaste + 20)
			elseif spellId == 12969 then 
				meleeHaste = (meleeHaste + 25)	
			elseif spellId == 12970 then 
				meleeHaste = (meleeHaste + 30)
			end
			
			if spellId == 16322 then 
				meleeHaste = (meleeHaste + 3)
			end	
			
			if spellId == 7396 then 
				meleeHaste = (meleeHaste + 10)
			end	
			
			if spellId == 16609 then
				meleeHaste = (meleeHaste + 15)
			end	
			
			if spellId == 15167 then 
				meleeHaste = (meleeHaste + 65)
			end	
			
			if spellId == 21165 then 
				meleeHaste = (meleeHaste + 20)
			end	
			
			if spellId == 28866 then 
				meleeHaste = (meleeHaste + 20)
			end	
			
			if spellId == 26635 then 
				local health = UnitHealth("player")
				local max_health = UnitHealthMax("player")
				local percenthealth = ((health/max_health) * 100)
				if percenthealth > 40 then	
					rangedHaste = (rangedHaste + 10)
					meleeHaste = (meleeHaste + 10)
					castHaste = (castHaste + 10)		
				else 
					rangedHaste = (rangedHaste + 30)
					meleeHaste = (meleeHaste + 30)	
					castHaste = (castHaste + 30)		
				end
		end	
	end
		
	elseif (classFilename == "ROGUE") then
		for i = 1, 40 do
			local _, _, _, _, _, _, _, _, _, spellId = UnitBuff("player",i, "HELPFUL")
			if not spellId then break end  
			
			if spellId == 5171 then 
				meleeHaste = (meleeHaste + 20)
			elseif spellId == 6774 then 
				meleeHaste = (meleeHaste + 30)
			end
			
			if spellId == 13877 then 
				meleeHaste = (meleeHaste + 20)
			end
			
			if spellId == 16322 then 
				meleeHaste = (meleeHaste + 3)
			end	
			
			if spellId == 7396 then 
				meleeHaste = (meleeHaste + 10)
			end	
			
			if spellId == 16609 then 
				meleeHaste = (meleeHaste + 15)
			end	
			
			if spellId == 15167 then 
				meleeHaste = (meleeHaste + 65)
			end	
			
			if spellId == 21165 then 
				meleeHaste = (meleeHaste + 20)
			end	
			
			if spellId == 28866 then 
				meleeHaste = (meleeHaste + 20)
			end	
			
			if spellId == 26635 then
				local health = UnitHealth("player")
				local max_health = UnitHealthMax("player")
				local percenthealth = ((health/max_health) * 100)
				if percenthealth > 40 then	
					rangedHaste = (rangedHaste + 10)
					meleeHaste = (meleeHaste + 10)
					castHaste = (castHaste + 10)		
				else 
					rangedHaste = (rangedHaste + 30)
					meleeHaste = (meleeHaste + 30)	
					castHaste = (castHaste + 30)		
				end
			end	
		end
	end

	local hasteHead = 0
	local hasteLegs = 0
	local hasteHands = 0
	local slotId = GetInventorySlotInfo("HandsSlot")
	local link = GetInventoryItemLink("player", slotId)

	if link then
		local itemId, enchantId = link:match("item:(%d+):(%d+)")
		if enchantId then
			enchantId = tonumber(enchantId)
			-- print("enchantId", enchantId, enchantId == 931)
			if enchantId == 931 then
				hasteHands = hasteHands + 1
			end
		end
	end

	local slotId = GetInventorySlotInfo("HeadSlot")
	local link = GetInventoryItemLink("player", slotId)
	
	if link then
		local itemId, enchantId = link:match("item:(%d+):(%d+)")
		if enchantId then
			enchantId = tonumber(enchantId)
			if enchantId == 2543 then
				hasteHands = hasteHands + 1
			end
		end
	end	
	
	local slotId = GetInventorySlotInfo("LegsSlot")
	local link = GetInventoryItemLink("player", slotId)
	
	if link then
		local itemId, enchantId = link:match("item:(%d+):(%d+)")
		if enchantId then
			enchantId = tonumber(enchantId)
			if enchantId == 2543 then
				hasteHands = hasteHands + 1
			end
		end
	end		

	local oilEnchants = 0
	local oilRegen = 0
	
	if (classFilename ~= "WARRIOR") and (classFilename ~= "ROGUE") and (classFilename ~= "HUNTER") then
		local hasMainHandEnchant, _, _, mainHandEnchantID, _, _, _, _ = GetWeaponEnchantInfo()
		if hasMainHandEnchant then
			if mainHandEnchantID == 2624 then
				oilEnchants = 4
				oilRegen = oilEnchants * 0.4
			elseif mainHandEnchantID == 2625 then
				oilEnchants = 8
				oilRegen = oilEnchants * 0.4
			elseif mainHandEnchantID == 2629 then
				oilEnchants = 12
				oilRegen = oilEnchants * 0.4
			end
		end
	end 

	local tierBonus = 0
	if tierPieces >= 3 then
		tierBonus = ((base) * 0.15)
		springtotem = springtotem + (springtotem * 0.25)
	end
	
	
	local zgMP5 = 0 	
	if zgPieces >= 2 then
		zgMP5 = 4
	end         
		
	SetText(self.Stats.HasteMelee, self, meleeHaste + hasteHands .. "%")  
	SetText(self.Stats.HasteRanged, self, rangedHaste + pouchCounter + hasteHands .. "%") 
	SetText(self.Stats.HasteCaster, self, castHaste .. "%") 		
	SetText(self.Stats.ManaRegen, self, format("%.0f", (base) + effectiveMR + innerregen + evoc + (scourgeMp5 * 0.4) + (totemicPower * 0.4) + (tierBonusShield * 0.4) + bowisdom + fishsoup + springtotem + tidetotem + siphonregen + swregen + felEnergy + oilRegen + drinkRegen + (warchief * 0.4) + (mageblood * 0.4) + (zgMP5 * 0.4) + (epiphany * 0.4) + (sageFish * 0.4)))
	SetText(self.Stats.CastingRegen, self, format("%.0f", effectiveMR + innercast + magearmor + (scourgeMp5 * 0.4) + (totemicPower * 0.4) + (tierBonusShield * 0.4) + talentRegen + bowisdom + fishsoup + springtotem + tidetotem + siphoncast + tierBonus + swregen + felEnergy + (warchief * 0.4) + (mageblood * 0.4) + oilRegen + (zgMP5 * 0.4) + (epiphany * 0.4) + (sageFish * 0.4)))   
	SetText(self.Stats.MP5Cast, self, format("%.0f", (mp5) + wismp5 + fishsoupmp5 + zgMP5 + oilEnchants + scourgeMp5 + totemicPower + warchief + mageblood + epiphany + sageFish)) 
	
	end        
end)
f:RegisterEvent("PLAYER_LOGIN")
-----------------------------------------------------

-------------------------------------------
-- Slash command to open the Settings frame
-------------------------------------------
SLASH_SINSTATS1 = "/sinstats"
SLASH_SS1 = "/ss"
function SlashCmdList.SINSTATS()
	AddonTable:ToggleConfig()
end
function SlashCmdList.SS()
	AddonTable:ToggleConfig()
end
--------------------
-- SinStats by Sinba
--------------------
local AddName, AddonTable = ...
local addVer = "1.2"

local className, classFilename, classId = UnitClass("player") 
local headerHeight = 15
local regenBase = 0
local regenCasting = 0
local speedColor = ""


AddonTable.DisplayOrder = {
	{ hud="CritChance", init=true, grp=1, text="Crit: ", textShort="CRIT: ", spell=275336, }, 
	{ hud="Haste", init=false, grp=1, text="Haste: ", textShort="HAS: ", spell=342245, },	
	{ hud="Mastery", init=true, grp=1, text="Mastery: ", textShort="MAS: ", spell=207684, },
	{ hud="Versatility", init=false, grp=1, text="Versatility: ", textShort="VER: ", spell=202137, },
	{ hud="VersaMitigate", init=false, grp=1, text="Versatility+: ", textShort="VER+: ", spell=152173, },
	{ hud="Avoidance", init=false, grp=1, text="Avoidance: ", textShort="AVO: ", spell=202138, },
	{ hud="Leech", init=false, grp=1, text="Leech: ", textShort="LEE: ", spell=204021, },	
	{ hud="AP", init=true, grp=2, text="AP: ", textShort="AP: ", spell=29838, },
	{ hud="DMG", init=false, grp=2, text="DMG: ", textShort="DMG: ", spell=315720, },
	{ hud="SpellPower", init=true, grp=3, text="Spell: +", textShort="SP: +", spell=321358, },	
	{ hud="Healing", init=true, grp=3, text="Healing: +", textShort="HEAL: ", spell=2050, },	
	{ hud="weaponSpeed", init=false, grp=2, text="AS: ", textShort="AS: ", spell=321281, },		
	{ hud="ManaRegen", init=true, grp=3, text="Mana Regen: ", textShort="MP5: ", spell=63733, },
	{ hud="EnergyRegen", init=true, grp=2, text="Energy Regen: ", textShort="ER: ", spell=212283, },	
	{ hud="Armor", init=true, grp=2, text="Armor: ", textShort="ARM: ", spell=320380, },
	{ hud="Dodge", init=false, grp=2, text="Dodge: ", textShort="DOD: ", spell=115008, },
	{ hud="Parry", init=false, grp=2, text="Parry: ", textShort="PAR: ", spell=118038, },
	{ hud="Block", init=false, grp=2, text="Block: ", textShort="BLO: ", spell=203177, }, 
	{ hud="Absorb", init=true, grp=2, text="Absorb: ", textShort="ABS: ", spell=343744, }, 	
	{ hud="Stagger", init=false, grp=2, text="Stagger: ", textShort="STAG: ", spell=280195, }, 	
	{ hud="Speed", init=true, grp=4, text="Speed: ", textShort="SPE: ", spell=109215, },
	{ hud="Durability", init=true, grp=4, text="Durability: ", textShort="DUR: ", spell=3100, },
--	{ hud="RepairCost", init=true, grp=4, text="Repair: ", textShort="REP: ", spell=286059, },	
	{ hud="Lag", init=false, grp=4, text="Lag: ", textShort="LAG: ", spell=190447, },
	{ hud="FPS", init=false, grp=4, text="FPS: ", textShort="FPS: ", spell=6196, },
}

--------------------------------
-- Initialize Icons
--------------------------------
for i=1, #AddonTable.DisplayOrder do
	AddonTable.DisplayOrder[i].icon = "|T"..select(3, GetSpellInfo(AddonTable.DisplayOrder[i].spell))..":0|t"
end

--------------------------------
-- Event Update Function
--------------------------------
function AddonTable:RunAllEvents()
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UPDATE_INVENTORY_DURABILITY")  
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_ATTACK_POWER")
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_RANGED_ATTACK_POWER")
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_DAMAGE")  
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_RANGEDDAMAGE")    
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_STATS")       
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "UNIT_AURA") 
	SinStatsFrame:GetScript("OnEvent")(SinStatsFrame, "CHARACTER_POINTS_CHANGED")
end

--------------------------------
-- SavedVariable Initialisation
--------------------------------
local function initSinStatsDB()
	if not SinStatsDB then
		SinStatsDB = {
			SinLockVar = false,
			SinHideVar = false,
			StatDirection = false,
			IconVar = true,
			SinOutline = false,			
			StatFontSize = 15,	
			SinMinimap = false,
			Stats = {},
		}
	end	
	for i=1, #AddonTable.DisplayOrder do
		if SinStatsDB.Stats[AddonTable.DisplayOrder[i].hud] == nil then
			SinStatsDB.Stats[AddonTable.DisplayOrder[i].hud] = AddonTable.DisplayOrder[i].init
		end
	end
	if not SinStatsDB.StatFontSize then
		SinStatsDB.StatFontSize = 12
	end
	if not SinStatsDB.minimap then
        SinStatsDB.minimap = {
            hide = false,
        }	
	end	
	
local DBObject = LibStub("LibDataBroker-1.1"):NewDataObject("SinStats", {
	type = "data source",
	text = "SinStats",
	icon = "Interface\\Icons\\Ability_demonhunter_infernalstrike1",
	
	OnTooltipShow = function(tooltip)
		tooltip:SetText("|cff0489d1SinStats|r")
		tooltip:AddLine("Click to |cffFFF468Open/Close|r the settings", 1, 1, 1)
		tooltip:Show()
	end,
	
	OnClick = function(self, button, down) 
		AddonTable:ToggleConfig()
	end,
})
AddonTable.sshMiniButton = LibStub("LibDBIcon-1.0")		
AddonTable.sshMiniButton:Register("SinStats", DBObject, SinStatsDB.minimap)	
 end
	 

---------------------------
-- Local Helper Functions
---------------------------
local function druidFormChk()
	if (classFilename == "DRUID") then
		local index = GetShapeshiftForm()
		if (index == 1) or (index == 3) then
			return true
		else
			return false
		end
	end
end

---------------------------
-- Stat update functions
---------------------------
local StatsFontSize = 12
local function SetFont(self)
	if not SinStatsDB.OutlineVar then
		self:SetFont("Fonts/ARIALN.ttf", StatsFontSize, "OUTLINE")
	else
		self:SetFont("Fonts/ARIALN.ttf", StatsFontSize, "THICKOUTLINE")
	end
end

local function CreateStatDisplay(parent, name, id)
	local f = parent:CreateFontString("$parent"..name, "OVERLAY", "GameFontNormal")
	f.ID = id
	SetFont(f)
	f:SetTextColor(1,1,1,1)
	parent.Stats[name] = f
	f:SetShown(SinStatsDB.Stats[name])
end

---------------------------
-- Creating the Stats Frame
---------------------------
local f = CreateFrame("frame", "SinStatsFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate")
f:SetBackdrop({
    bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
    tile=1, tileSize=0, edgeSize=0,
})
f:SetBackdropColor(1,1,1,1)
f:SetWidth(200)
f:SetHeight(headerHeight)
f:SetPoint("CENTER",UIParent)
f:SetMovable(true)
f:SetUserPlaced(true)
f:SetClampedToScreen(false)
f:RegisterForDrag("LeftButton")
f:SetScript("OnDragStart", function(self) self:StartMoving() end)
f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
f:SetFrameStrata("BACKGROUND")
f.DragText = f:CreateFontString(nil, "OVERLAY");
f.DragText:SetFontObject("GameFontHighlight");
f.DragText:SetTextColor(1, 1, 1)
f.DragText:SetText("SinStats")
f.DragText:SetPoint("CENTER")

f.Stats = {}
function f:ResizeStats()
	StatsFontSize = SinStatsDB.StatFontSize
	for k, v in pairs(self.Stats) do
		SetFont(v)
	end
end

local function AnchorStat(stat, horizontal, first, last)
	stat:ClearAllPoints()
	if not first then
		stat:SetPoint("TOPLEFT", 0, -headerHeight)
	else
		if horizontal then
			stat:SetPoint("LEFT", last, "RIGHT", 7, 0)	
		else
			stat:SetPoint("TOPLEFT", last, "BOTTOMLEFT")
		end				
	end
	return true, stat
end

local rowList = {}
function f:RedrawStats()
    local first, last
    local horizontal = SinStatsDB.SinDirection
    local rows = SinStatsDB.StatRows or 1
    table.wipe(rowList)
    if not SinStatsDB.GroupOrder then
        for i=1, #AddonTable.DisplayOrder do
            local k = AddonTable.DisplayOrder[i].hud
            local v = self.Stats[k]
            if v:IsShown() then
                if not horizontal or rows == 1 then
                    first, last = AnchorStat(v, horizontal, first, last)
                else        
                    tinsert(rowList, v)
                end
            end
        end
    else
        for i=1, #AddonTable.Groups do
            for n=1, #AddonTable.DisplayOrder do
                if AddonTable.DisplayOrder[n].grp == i then
                    local k = AddonTable.DisplayOrder[n].hud
                    local v = self.Stats[k]
                    if v:IsShown() then
                        if not horizontal or rows == 1 then
                            first, last = AnchorStat(v, horizontal, first, last)
                        else        
                            tinsert(rowList, v)
                        end
                    end
                end
            end
        end
    end
    if horizontal and rows > 1 then
        local totalRows = #rowList
        local maxOnRow = math.floor(totalRows / rows)
        local first, last
        for i=1, totalRows do
            if not first then
                AnchorStat(rowList[i], horizontal, first, last)
                first = rowList[i]
                last = first
            else
                rowList[i]:ClearAllPoints()
                if horizontal then 
                    rowList[i]:SetPoint("LEFT", last, "RIGHT", 7, 0)
                else
                    rowList[i]:SetPoint("TOPLEFT", last, "BOTTOMLEFT", 0, -3)
                end
--              AnchorStat(rowList[i], horizontal, first, last)
                last = rowList[i]
                horizontal = true
            end
            if mod(i, maxOnRow) == 0 then
                last = first
                first = rowList[i+1]
                horizontal = nil
            end
        end
    end
end

local updatespeed = 1.0
local TimeToNextUpdate = updatespeed

local function SetText(self, parent, text)
	local Icon = parent.AddIcons and AddonTable.DisplayOrder[self.ID].icon or ""
	if SinStatsDB.SinAbrev then
		self:SetText(Icon..AddonTable.DisplayOrder[self.ID].textShort..text) 
	else 
		self:SetText(Icon..AddonTable.DisplayOrder[self.ID].text..text)
	end
end

local function OnUpdate(self, elapsed)
	TimeToNextUpdate = TimeToNextUpdate - elapsed
	if TimeToNextUpdate > 0 then return end
	TimeToNextUpdate = updatespeed
	
	-- Armor
	local base, effectiveArmor, armor, posBuff, negBuff = UnitArmor("player")
	SetText(self.Stats.Armor, self, effectiveArmor)   
	
	-- Absorb
	local absorb = UnitGetTotalAbsorbs("player")
	SetText(self.Stats.Absorb, self, absorb)   
	
	-- Stagger
	local stagger, staggerAgainstTarget = C_PaperDollInfo.GetStaggerPercentage("player")
	SetText(self.Stats.Stagger, self, ("%.2f"):format(stagger) .. "%")

	-- Critical Strike
	local totalCrit = 0
	local critChance = GetCritChance("player")
	local critSpellChance = GetSpellCritChance("player")
	local critRangedChance = GetRangedCritChance("player")
	local critTable = {critChance, critSpellChance, critRangedChance}
	table.sort(critTable)
	totalCrit = critTable[#critTable]	
	SetText(self.Stats.CritChance, self, ("%.2f"):format(totalCrit) .. "%")
	
	-- Haste
	local haste = GetHaste()
	SetText(self.Stats.Haste, self, ("%.2f"):format(haste) .. "%") 
	
	-- Energy Regen
	local energyRegen = 0
	energyRegen = 10 + (haste * 0.1)
	SetText(self.Stats.EnergyRegen, self, ("%.1f"):format(energyRegen)) 

	-- Mastery
	local mastery, coefficient = GetMasteryEffect()
	SetText(self.Stats.Mastery, self, ("%.2f"):format(mastery) .. "%") 
	
	-- Versatility
    local verDamage = GetVersatilityBonus(29) + GetCombatRatingBonus(29)
	local verMitigate = GetVersatilityBonus(31) + GetCombatRatingBonus(31)
	SetText(self.Stats.Versatility, self, ("%.2f"):format(verDamage))
	SetText(self.Stats.VersaMitigate, self, ("%.2f"):format(verMitigate))	
	
	-- Avoidance
	local avoidance = GetAvoidance()
	SetText(self.Stats.Avoidance, self, ("%.2f"):format(avoidance) .. "%") 
	
	-- Leech
	local leech = GetLifesteal()
	SetText(self.Stats.Leech, self, ("%.2f"):format(leech) .. "%") 
	
	-- Attack Speed
	local mainSpeed, offSpeed = UnitAttackSpeed("player")
	local speed = UnitRangedDamage("player");
	local weapSpeed = 0
	if offSpeed == nil then
		offSpeed = ""
	else
		offSpeed = " / " .. ("%.2f"):format(offSpeed)
	end
	if mainSpeed > 0 then
		weapSpeed = mainSpeed
	elseif speed > 0 then
		weapSpeed = speed
	else
		weapSpeed = 0
	end
	SetText(self.Stats.weaponSpeed, self, ("%.2f"):format(weapSpeed) .. offSpeed)

	-- Mana Regen
	local regenBase, regenCasting = GetManaRegen()
	regenBase = regenBase * 5
	regenCasting = (regenCasting * 5)
	SetText(self.Stats.ManaRegen, self, ("%.2f"):format(regenBase))

	-- Healing Spell Power
	local SinHealSpell = GetSpellBonusHealing();
	SetText(self.Stats.Healing, self, ("%.0f"):format(SinHealSpell));  

	-- Spell Power
	local spellPower = 0
	local SinHolySpell = GetSpellBonusDamage(2);
	local SinFireSpell = GetSpellBonusDamage(3);	
	local SinNatureSpell = GetSpellBonusDamage(4);
	local SinFrostSpell = GetSpellBonusDamage(5);  	
	local SinShadowSpell = GetSpellBonusDamage(6);                        
	local SinArcaneSpell = GetSpellBonusDamage(7);  
	local spellTable = {SinFrostSpell, SinFireSpell, SinArcaneSpell, SinShadowSpell, SinNatureSpell, SinHolySpell}
	table.sort(spellTable)
	spellPower = spellTable[#spellTable]
	SetText(self.Stats.SpellPower, self, ("%.0f"):format(spellPower));

	-- Dodge
	local dodgeChance = GetDodgeChance("player");
	SetText(self.Stats.Dodge, self, ("%.2f"):format(dodgeChance) .. "%");       

	-- Parry
	local parryChance = GetParryChance("player");
	SetText(self.Stats.Parry, self, ("%.2f"):format(parryChance) .. "%"); 

	-- Block
	local blockChance = GetBlockChance("player");
	SetText(self.Stats.Block, self, ("%.2f"):format(blockChance) .. "%");    

	local currentSpeed, runSpeed, flightSpeed, swimSpeed = GetUnitSpeed("player")
	local fullSpeed = GetUnitSpeed("player") / 7 * 100
	if fullSpeed == 0 or fullSpeed == 100 then
		speedColor = ""
	elseif fullSpeed < 100 then
		speedColor = "|cffC41E3A"
	elseif fullSpeed > 100 then
		speedColor = "|cff00f26d"
	end
	SetText(self.Stats.Speed, self, speedColor .. string.format("%d%%", ("%.0f"):format(fullSpeed)));

	local framerate = GetFramerate()
	if framerate < 30 then
		SetText(self.Stats.FPS, self, "|cffC41E3A" .. floor(framerate) .. "|r")
	elseif framerate > 30 and framerate < 50 then
		SetText(self.Stats.FPS, self, "|cffFF7C0A" .. floor(framerate) .. "|r")
	elseif framerate > 50 then
		SetText(self.Stats.FPS, self, "|cff00f26d" .. floor(framerate) .. "|r")
	end

	local _, _, _, lagWorld = GetNetStats();
	if lagWorld < 90 then
		SetText(self.Stats.Lag, self, "|cff00f26d" .. lagWorld .. " ms|r"); 
	elseif lagWorld >= 90 and lagWorld < 200 then
		SetText(self.Stats.Lag, self, "|cffFF7C0A" .. lagWorld .. " ms|r"); 
	elseif lagWorld > 200 then
		SetText(self.Stats.Lag, self, "|cffC41E3A" .. lagWorld .. " ms|r"); 
	end	
	
	
end
 
f:SetScript("OnEvent", function (self, event, ...)
	--local spirit, effectiveSpirit, posBuffSpirit, negBuffSpirit = UnitStat("player", 5)
	if event == "PLAYER_LOGIN" then
		print("|cff00f26dSinStats v" .. addVer .. " loaded|r. Type |cff00f26d/sinstats|r or |cff00f26d/ss|r to open the settings.")
		initSinStatsDB()
		self.AddIcons = SinStatsDB.IconVar
		StatsFontSize = SinStatsDB.StatFontSize
		for i=1, #AddonTable.DisplayOrder do
			local Settings = AddonTable.DisplayOrder[i]
			if SinStatsDB and SinStatsDB.Stats[Settings.hud] == nil then
				print("|cffff0000SinsStats:|r Missing Saved Variable:|cff00ff00", Settings.hud)
			else
				CreateStatDisplay(self, Settings.hud, i)
			end
		end
		self:ResizeStats()
		self:RedrawStats()
		
		
		
		StaticPopupDialogs["SINSTATS_HUD_RESET"] = {
			text = "Reset the HUD's position ?",
			button1 = "Yes",
			button2 = "No",
			timeout = 0,
			whileDead = true,
			hideOnEscape = false,		
			OnAccept = function(self) 
				SinStatsFrame:SetUserPlaced(false)
				SinStatsFrame:ClearAllPoints()
				SinStatsFrame:SetPoint("CENTER", 0, 0)
				SinStatsFrame:SetUserPlaced(true)
			end,
			OnCancel = function(self) end, 
		}
		self:RegisterEvent("UNIT_STATS", "player")
		self:RegisterUnitEvent("UNIT_AURA", "player")
		self:RegisterEvent("CHARACTER_POINTS_CHANGED")
		self:RegisterEvent("UPDATE_INVENTORY_DURABILITY")
		self:RegisterEvent("UNIT_DAMAGE")
		self:RegisterEvent("UNIT_RANGEDDAMAGE")
		self:RegisterEvent("UNIT_ATTACK_POWER")
		self:RegisterEvent("UNIT_RANGED_ATTACK_POWER")

		AddonTable:RunAllEvents()
		AddonTable:UpdateStatus()
		self:SetScript("OnUpdate", OnUpdate)  

	elseif event == "UPDATE_INVENTORY_DURABILITY" then
		local Durability, Current, Full, Percent
		local LowestCurrent, LowestFull, t1, t2, t3 = 500, 0, 0, 0, 100
		for i=1,19 do
			Current, Full = GetInventoryItemDurability(i)
			if Current and Full then
				Percent = floor(100*Current/Full + 0.5)
				if (Percent < t3) then
					t3 = Percent
				end
				if (Current < LowestCurrent) then
					LowestCurrent = Current
					LowestFull = Full
				end
				t1 = t1 + Current
				t2 = t2 + Full
			end
		end
		if t2 == 0 then
			Durability = "N/A"
		else
			Durability = floor(t1 * 100 / t2)
		end
		local Text = ""
		if type(Durability) == "number" then
			if Durability > 50 then
				Text = string.format("|cff%2xff00", ((Durability > 50) and (255 - 2.55*Durability) or (2.55*Durability)), Durability) .. Text
			else
				Text = string.format("|cffff%2x00", (2.55*Durability), Durability) .. Text
			end
			Text = Text..Durability.."%"
		end
		SetText(self.Stats.Durability, self, Text)         

	elseif event == "UNIT_ATTACK_POWER" or event == "UNIT_RANGED_ATTACK_POWER" then
		local base, posBuff, negBuff = UnitAttackPower("player");
		local effectiveAP = base + posBuff + negBuff;
		local base, posBuff, negBuff = UnitRangedAttackPower("player");
		local effectiveRanged = base + posBuff + negBuff;
		local totalAP = 0
		local apTable = {effectiveAP, effectiveRanged}
		table.sort(apTable)
		totalAP = apTable[#apTable]		
		SetText(self.Stats.AP, self, totalAP); 

	elseif event == "UNIT_DAMAGE" or event == "UNIT_RANGEDDAMAGE" then
		local lowDmg, hiDmg, offlowDmg, offhiDmg, posBuff, negBuff, percentmod = UnitDamage("player");
		local dmgeffect = hiDmg;		
		local speed, lowDmg, hiDmg, posBuff, negBuff, percent = UnitRangedDamage("player");
		local Rdmgeffect = hiDmg;
		local dmgTable = {dmgeffect, Rdmgeffect}
		local totalDmg = 0
		table.sort(dmgTable)
		totalDmg = dmgTable[#dmgTable]				
 		SetText(self.Stats.DMG, self, ("%.1f"):format(totalDmg));

	elseif event == "CHARACTER_POINTS_CHANGED" then
		self:RedrawStats()
		
	end        
end)
f:RegisterEvent("PLAYER_LOGIN")


-------------------------------------------
-- Slash command to open the Settings frame
-------------------------------------------
SLASH_SINSTATS1 = "/sinstats"
SLASH_SS1 = "/ss"
function SlashCmdList.SINSTATS()
	AddonTable:ToggleConfig()
end
function SlashCmdList.SS()
	AddonTable:ToggleConfig()
end